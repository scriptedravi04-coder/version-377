// v378: fixes from the v377 QA report (H1–H3, M1–M13, L1–L14).
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import { campaignBudgetProblem, DEFAULT_MAX_CAMPAIGN_BUDGET } from "./riskControls";
import { stripPrivateProfileFields } from "./profilePrivacy";
import { briefForOutsider, isBriefOwner } from "./ugcGuards";
import { loginIpAllowed, _resetLoginIpHits, withHashSlot, HASH_SLOTS, escapeLike } from "./authSecurity";
import { requiredAdminPermission } from "./adminPermissions";
import { sanitizeHtml } from "../src/utils/sanitizeHtml";
import express from "express";
import type { AddressInfo } from "net";
import { setupCreatorReviewGate } from "./creatorReviewGate";

const read = (p: string) => fs.readFileSync(path.join(__dirname, "..", p), "utf8");
const rc = { payoutFreezeAll: false, minWithdrawal: 0, minBudget: null, maxBudget: null };

describe("v378 QA fixes", () => {
  it("H1: quick-admin PIN entry removed completely (Ravi: app is public)", () => {
    const s = read("backend/server.ts");
    expect(s).not.toContain('token.startsWith("dev_bypass_admin|")');
    expect(s).not.toContain("ADMIN_QUICK_PIN || ");
  });
  it("H2: security headers + no x-powered-by", () => {
    const s = read("backend/server.ts");
    expect(s).toContain('app.disable("x-powered-by")');
    expect(s).toContain('"X-Content-Type-Options", "nosniff"');
    expect(s).toContain("frame-ancestors 'self'");
  });
  it("H3: per-IP login limit and at most HASH_SLOTS password checks at once", async () => {
    _resetLoginIpHits();
    let ok = 0; for (let i = 0; i < 40; i++) if (loginIpAllowed("1.2.3.4", 1000)) ok++;
    expect(ok).toBe(30);
    expect(loginIpAllowed("1.2.3.4", 1000 + 61_000)).toBe(true);
    let running = 0, peak = 0;
    await Promise.all(Array.from({ length: 12 }, () => withHashSlot(async () => { running++; peak = Math.max(peak, running); await new Promise((r) => setTimeout(r, 5)); running--; })));
    expect(peak).toBe(HASH_SLOTS);
  });
  it("M1: an outsider gets the brief without private fields; the owner sees all", () => {
    const b = { id: "b1", brand_id: "brand1", title: "T", razorpay_order_id: "order_x", brand_email: "a@b.c", deliverable_url: "u", brand: { name: "B", email: "x@y.z" } };
    const o = briefForOutsider(b);
    expect(o).toMatchObject({ id: "b1", title: "T", brand: { name: "B" } });
    expect(o.razorpay_order_id).toBeUndefined(); expect(o.brand_email).toBeUndefined(); expect(o.deliverable_url).toBeUndefined(); expect(o.brand.email).toBeUndefined();
    expect(isBriefOwner({ user_id: "brand1", role: "brand" }, b)).toBe(true);
    expect(isBriefOwner({ user_id: "c1", role: "creator" }, b)).toBe(false);
    expect(isBriefOwner({ user_id: "c1", role: "creator", parent_brand_id: "" }, { brand_id: "" })).toBe(false);
  });
  it("M2/M4: LIKE wildcards are escaped", () => {
    expect(escapeLike("%")).toBe("\\%");
    expect(read("backend/creatorCoupons.ts")).toContain("/^[A-Z0-9_-]{2,40}$/");
    expect(read("backend/auth_routes.ts")).toContain(".ilike('email', escapeLike(cleanEmail)).neq('verified', true)");
  });
  it("M5: kyc-action needs manage_kyc", () => {
    expect(requiredAdminPermission("POST", "/admin/users/u1/kyc-action")).toBe("manage_kyc");
    expect(requiredAdminPermission("POST", "/admin/users/u1/ban")).toBe("manage_users");
  });
  it("M8: budget validation", () => {
    expect(campaignBudgetProblem(-5, 100, rc)).toMatch(/negative/);
    expect(campaignBudgetProblem(5000, 1000, rc)).toMatch(/Minimum/);
    expect(campaignBudgetProblem(1000, DEFAULT_MAX_CAMPAIGN_BUDGET + 1, rc)).toMatch(/can't be more/);
    expect(campaignBudgetProblem(1000, 5000, rc)).toBeNull();
    expect(campaignBudgetProblem(0, 0, rc)).toBeNull();
  });
  it("L2: internal / new private-sounding columns are hidden", () => {
    const o: any = stripPrivateProfileFields({ name: "A", managed_by_agency_id: "x", reviewed_at: "t", payout_secret: "s", gst_number: "g", bio: "b" });
    expect(o).toEqual({ name: "A", bio: "b" });
  });
  it("L1: allow-list sanitizer drops polyglots and unknown tags", () => {
    const out = sanitizeHtml('<p>Hi<noscript><p title="</noscript><img src=x onerror=alert(1)>"></noscript></p><title><img src=x onerror=alert(1)></title><custom-el>t</custom-el>');
    expect(out).not.toMatch(/onerror/i);
    expect(out).not.toMatch(/<noscript|<title|<custom-el/i);
    expect(sanitizeHtml('<a href="javascript:alert(1)">x</a><b>ok</b>')).toBe("<a>x</a><b>ok</b>");
  });
  it("creator KYC: PAN / IFSC format checked before the locked submit route", async () => {
    const app = express(); app.use(express.json()); const r = express.Router();
    setupCreatorReviewGate(r, { supabase: null, privilegedSupabase: null, getDb: () => ({}), parseAuthUser: async () => null });
    r.post("/creator/kyc/submit", (_q, s2) => s2.json({ ok: true }));
    app.use(r);
    const srv = app.listen(0); const base = `http://127.0.0.1:${(srv.address() as AddressInfo).port}`;
    const post = (b: any) => fetch(base + "/creator/kyc/submit", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b) });
    expect((await post({ panNumber: "ABC123" })).status).toBe(400);
    expect((await post({ panNumber: "abcde1234f", bankIfsc: "SBIN0001234" })).status).toBe(200);
    expect((await post({ panNumber: "ABCDE1234F", ifsc: "SBI001" })).status).toBe(400);
    srv.close();
  });
  it("admin documents: no uploaded_files[n] guessing for Aadhaar / UPI slots", () => {
    expect(read("src/components/admin/UserEnforcementPanel.jsx")).not.toContain("uploaded_files?.[1]");
    expect(read("src/components/admin/userEnforcement/UploadedDocumentsCard.jsx")).toContain("{aadhaarFrontUrl && (<>");
  });
});
