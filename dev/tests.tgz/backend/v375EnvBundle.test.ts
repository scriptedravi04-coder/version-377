// v375 (Ravi: one hosting secret instead of many): YBEX_ENV = a .env-style block; it fills only missing settings and
// runs before any other server file (server.ts imports it first).
import { describe, it, expect } from "vitest";
import fs from "fs";
import { parseEnvBundle, applyEnvBundle } from "./envBundle";

describe("v375 · YBEX_ENV", () => {
  it("reads KEY=VALUE lines like a .env file", () => {
    const p = parseEnvBundle(`# comment\n\nSESSION_SECRET      = 1370abc\nexport CRON_SECRET="a=b"\nRESEND_FROM_EMAIL='Ybex <noreply@ybexmedia.in>'\nnot a line\nFCM_SERVICE_ACCOUNT_JSON={"type":"service_account","private_key":"-----BEGIN\\nX"}\r\n`);
    expect(p.SESSION_SECRET).toBe("1370abc");
    expect(p.CRON_SECRET).toBe("a=b");
    expect(p.RESEND_FROM_EMAIL).toBe("Ybex <noreply@ybexmedia.in>");
    expect(JSON.parse(p.FCM_SERVICE_ACCOUNT_JSON).type).toBe("service_account");
    expect(Object.keys(p)).toHaveLength(4);
  });
  it("never overwrites a setting that is set on its own; empty values are skipped", () => {
    const env: any = { YBEX_ENV: "A=1\nB=2\nC=\nYBEX_ENV=loop", B: "kept", D: "" };
    expect(applyEnvBundle(env)).toEqual(["A"]);
    expect(env).toMatchObject({ A: "1", B: "kept" });
    expect(env.C).toBeUndefined();
  });
  it("runs first: server.ts imports it before the server", () => {
    const s = fs.readFileSync("server.ts", "utf8");
    expect(s.indexOf('import "./backend/envBundle"')).toBeGreaterThanOrEqual(0);
    expect(s.indexOf('import "./backend/envBundle"')).toBeLessThan(s.indexOf('import "./backend/server.ts"'));
    expect(fs.readFileSync("backend/envBundle.ts", "utf8")).not.toMatch(/console\.log\([^)]*\bv\b/); // values never logged
  });
});

describe("v378 · YBEX_ENV saved as one line", () => {
  it("reads every key when the secret box turned new lines into spaces or \\n", () => {
    const a = parseEnvBundle(`SUPABASE_URL=https://x.supabase.co SUPABASE_SERVICE_ROLE_KEY=sb_secret_abc GOOGLE_CLIENT_ID=123.apps.googleusercontent.com`);
    expect(a.SUPABASE_SERVICE_ROLE_KEY).toBe("sb_secret_abc");
    expect(a.GOOGLE_CLIENT_ID).toBe("123.apps.googleusercontent.com");
    const b = parseEnvBundle(`SUPABASE_URL=https://x.supabase.co\\nSUPABASE_SERVICE_ROLE_KEY=sb_secret_abc\\nFCM={"private_key":"-----BEGIN\\nX"}`);
    expect(b.SUPABASE_SERVICE_ROLE_KEY).toBe("sb_secret_abc");
    expect(b.FCM).toBe('{"private_key":"-----BEGIN\\nX"}');
  });
});
