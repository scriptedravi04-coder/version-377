// v363 (Ravi's portfolio design 1h / 1d / 1g / 1e): the item model + the screen wiring.
import { describe, it, expect } from "vitest";
import fs from "fs";
import {
  shortCount, parseItem, parseList, groupByBrand, groupLine, itemStat, mediaToPending, finalizeItem, tagQueue,
  suggestBrands, linkKey, toSaved, cleanBrand,
} from "../src/components/portfolio/portfolioModel";

const read = (p: string) => fs.readFileSync(p, "utf8");

describe("v363 portfolio model", () => {
  it("Indian short counts, nothing for nothing", () => {
    expect(shortCount(42100)).toBe("42.1K");
    expect(shortCount(120000)).toBe("1.2L");
    expect(shortCount(12500000)).toBe("1.3Cr");
    expect(shortCount(999)).toBe("999");
    expect(shortCount(0)).toBeNull();
    expect(shortCount("x")).toBeNull();
  });

  it("reads every old shape: bare link, JSON string, old object", () => {
    const list = parseList([
      "https://www.instagram.com/reel/DXUc97pgTs7/?igsh=abc",
      JSON.stringify({ id: "1", title: "Nykaa · Instagram reel", brand_name: "@Nykaa", content_url: "https://instagram.com/p/AAAAA1/", views: 900 }),
      { id: "ig_9", brand_name: "", content_url: "https://instagram.com/reel/BBBBB2/" },
      "", null,
    ]);
    expect(list).toHaveLength(3);
    expect(list[0].content_url).toContain("DXUc97pgTs7");
    expect(list[0].platform).toBe("instagram");
    expect(list[1].brand_name).toBe("Nykaa");
    expect(list[1].views).toBe(900);
    expect(list[2].source).toBe("ig");
    expect(parseItem({ title: "no link" })).toBeNull();
  });

  it("groups by brand (case-insensitive), no-brand last as Other work, likes when no views", () => {
    const items = parseList([
      { id: "a", brand_name: "Lenskart", content_url: "https://x.co/1", views: 42100 },
      { id: "b", brand_name: "lenskart", content_url: "https://x.co/2", views: 15900 },
      { id: "c", brand_name: "", content_url: "https://x.co/3" },
      { id: "d", brand_name: "boAt", content_url: "https://x.co/4", likes: 1200 },
    ]);
    const g = groupByBrand(items);
    expect(g.map((x) => x.brand)).toEqual(["Lenskart", "boAt", "Other work"]);
    expect(groupLine(g[0])).toBe("2 reels · 58K views");
    expect(groupLine(g[1])).toBe("1 reel · 1.2K likes");
    expect(groupLine(g[2])).toBe("1 reel");
    expect(itemStat(items[2])).toBeNull();
  });

  it("Instagram media → pending → saved item; brand required by the sheet; UI keys dropped", () => {
    const p = mediaToPending({ id: "17", permalink: "https://instagram.com/reel/CCCCC3/", thumb: "https://scontent.cdninstagram.com/t.jpg", likes: 500, views: null, at: "2026-09-12T10:00:00+0000", brand: "lenskart", caption: "#ad @lenskart", collab: true });
    expect(p.id).toBe("ig_17");
    expect(p.suggested).toBe("Lenskart"); // first letter up from the caption @mention
    const saved = finalizeItem({ ...p, cover: "https://sb/storage/v1/object/public/avatars/portfolio/u/ig_17.webp" }, "@Lenskart ");
    expect(saved.brand_name).toBe("Lenskart");
    expect(saved.title).toBe("Lenskart collab");
    expect(saved.cover).toContain("/avatars/portfolio/");
    expect(saved.views).toBeNull(); // never invented
    expect(saved.likes).toBe(500);
    const out = toSaved([{ ...saved, thumb: "x", suggested: "y", collab: true }])[0] as any;
    expect(out.thumb).toBeUndefined();
    expect(out.suggested).toBeUndefined();
  });

  it("tag queue groups by the caption brand; unbranded ones are tagged one by one", () => {
    const q = tagQueue([
      { id: "1", suggested: "lenskart" }, { id: "2", suggested: "Lenskart" }, { id: "3", suggested: "" }, { id: "4", suggested: "" },
    ] as any);
    expect(q.map((g) => g.items.length)).toEqual([2, 1, 1]);
  });

  it("brand suggestions + duplicate links by Instagram shortcode", () => {
    const items = parseList([{ id: "a", brand_name: "Lenskart", content_url: "https://x.co/1" }, { id: "b", brand_name: "Mamaearth", content_url: "https://x.co/2" }]);
    expect(suggestBrands("len", items).map((s) => s.brand)).toEqual(["Lenskart"]);
    expect(linkKey("https://www.instagram.com/reel/DXUc97pgTs7/?igsh=1")).toBe(linkKey("https://instagram.com/reels/DXUc97pgTs7"));
    expect(cleanBrand("  @boAt   Nirvana ")).toBe("boAt Nirvana");
  });
});

describe("v363 portfolio screens", () => {
  it("screen file stays layout-only and uses the new pieces", () => {
    const s = read("src/pages/creator/profileScreens/PortfolioScreen.jsx");
    expect(s).not.toMatch(/\bapi\.(get|post|put|patch|delete)\(/);
    for (const t of ["<PortfolioEmpty", "<PortfolioStacks", "<AddCollabsScreen", "<BrandSheet", "<InstagramReelPicker", 'variant="glass"']) expect(s).toContain(t);
  });
  it("design copy is there", () => {
    const v = read("src/components/portfolio/PortfolioViews.jsx");
    for (const t of ["No brand collabs yet", "Add your first collab", "collab", "found on @"]) expect(v).toContain(t);
    const a = read("src/components/portfolio/AddCollabsScreen.jsx");
    for (const t of ["Add collabs", "Select all", "Paste link", "Upload", "Brand name next", "Next · tag", "copyCovers"]) expect(a).toContain(t);
    const t = read("src/components/portfolio/TagBrandSheet.jsx");
    for (const x of ["How brands will see it", "TAG THE BRAND", "They'll be grouped under this name on your profile.", "in caption", "Not a brand collab", "already"]) expect(t).toContain(x);
  });
  it("calls the v363 server routes", () => {
    const api = read("src/components/portfolio/portfolioApi.js");
    for (const r of ["creator/portfolio/ig-media", "creator/portfolio/link-preview", "creator/portfolio/covers", "upload?bucket=profile-assets"]) expect(api).toContain(r);
  });
});
