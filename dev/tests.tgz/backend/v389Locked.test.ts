import { describe, it, expect } from "vitest";
import fs from "fs";
import { isEscrowDepositRow, isPartRefundedDeposit } from "./campaignGuards";
import { netAfterPartialRefund } from "./adminMoney";
import { isAcceptableDraftRef } from "./ugc_routes";

// v389 — the six LOCKED-file fixes Ravi approved in writing on 30 Oct 2026 (QA report v382). Logged in docs/code/PROTECTED_CHANGES.md.
const read = (f: string) => fs.readFileSync(f, "utf8");

describe("v389 · 1. a PART refund does not turn the deposit into a refund row (no second payout row)", () => {
  const deposit = { status: "SUCCESS", gross_amount: 20000, brand_paid_amount: 21600, refund_status: "PROCESSED", refund_amount: 2000 };
  it("₹2,000 of ₹20,000 refunded → still the deposit", () => {
    expect(isEscrowDepositRow(deposit)).toBe(true);
    expect(isPartRefundedDeposit(deposit)).toBe(true);
  });
  it("a service-fee-only refund (₹800) is still the deposit", () => {
    expect(isEscrowDepositRow({ ...deposit, refund_amount: 800 })).toBe(true);
  });
  it("a FULL refund, a REFUNDED row, or a refund with no paid amount are still refund rows (old rule)", () => {
    expect(isEscrowDepositRow({ ...deposit, refund_amount: 21600 })).toBe(false);
    expect(isEscrowDepositRow({ ...deposit, status: "REFUNDED" })).toBe(false);
    expect(isEscrowDepositRow({ status: "SUCCESS", refund_amount: 100 })).toBe(false);
    expect(isEscrowDepositRow({ status: "SUCCESS", refund_status: "PROCESSED", refund_amount: 100 })).toBe(false);
  });
  it("unchanged: plain deposits, held escrow, pending rows", () => {
    expect(isEscrowDepositRow({ status: "SUCCESS", refund_status: "NONE", refund_amount: 0, gross_amount: 100 })).toBe(true);
    expect(isEscrowDepositRow({ status: "INITIATED", escrow_hold: true })).toBe(true);
    expect(isEscrowDepositRow({ status: "PENDING" })).toBe(false);
  });
  it("the creator's net on approval is minus the refunded deal part", () => {
    expect(netAfterPartialRefund({ refund_status: "PROCESSED", refund_amount: 2000 }, 20000)).toBe(18000);
    const s = read("backend/campaign_lifecycle.ts");
    expect(s).toContain("txUpdate.creator_net_amount = netAfterPartialRefund(tx, netAmount)");
    expect(s).toContain("brand_paid_amount, brand_fee_amount, brand_fee_gst, fee_correction_note");
  });
});

describe("v389 · 2. one Razorpay payment is recorded once", () => {
  it("same-order calls run one after the other, and a later duplicate row removes itself", () => {
    const s = read("backend/payment_routes.ts");
    expect(s).toContain("const escrowLocks = new Map<string, Promise<unknown>>()");
    expect(s).toContain("async function persistEscrowPaymentInner(");
    expect(s).toMatch(/async function persistEscrowPayment\(args: Parameters<typeof persistEscrowPaymentInner>\[0\]\)/);
    expect(s).toContain("sameOrder[0].id !== txnId");
    expect(s).toMatch(/\.delete\(\)\.eq\('id', txnId\)/);
  });
});

describe("v389 · 3. the word 'ugc' in a title never makes a campaign a UGC order", () => {
  for (const f of ["src/components/chat/ChatBox.jsx", "src/components/chat/dealState.js"]) {
    it(f, () => {
      const s = read(f);
      expect(s).not.toMatch(/title\?\.toLowerCase\(\)\?\.includes\(["']ugc["']\)/);
      expect(s).toMatch(/currentThread\?\.id\?\.startsWith\(["']thread_ugc_["']\)/); // type / id rules stay
    });
  }
});

describe("v389 · 4. a UGC first draft must be a file or a real link", () => {
  it("accepts our storage paths, media links and web links", () => {
    for (const v of ["https://drive.google.com/file/d/abc/view", "drive.google.com/file/d/abc", "https://www.dropbox.com/s/x/y.mp4", "/api/media?src=ugc-videos%2Fo1.mp4",
      "ugc-videos/ord_1-1700000000.mp4", "campaign-deliverables/t-1.mp4", "https://ugc-videos/o1.mp4", "https://abc.supabase.co/storage/v1/object/sign/content-submissions/ugc-videos/a.mp4?token=1"])
      expect(isAcceptableDraftRef(v), v).toBe(true);
  });
  it("refuses sentences and junk", () => {
    for (const v of ["", "   ", "will send tomorrow", "ok bhai kal bhejta hu", "video ready hai", "javascript:alert(1)", "localhost", "abc", "https://", "mailto:a@b.co"])
      expect(isAcceptableDraftRef(v), v).toBe(false);
  });
  it("the draft handler uses it before anything is saved", () => {
    expect(read("backend/ugc_routes.ts")).toMatch(/if \(!isAcceptableDraftRef\(finalVideoUrl\)\) \{[\s\S]{0,260}INVALID_DRAFT_LINK/);
  });
});

describe("v389 · 5. the other party is told about counter / accept / agreement / sign / change requests", () => {
  const s = read("backend/deals_chat_routes.ts");
  it("deals_chat_routes: four step notifications through one helper", () => {
    expect(s).toContain("const notifyOtherParty = async");
    for (const t of ["counter_offer", "counter_accepted", "agreement_ready", "agreement_signed", "agreement_both_signed"]) expect(s, t).toContain(`"${t}"`);
    expect((s.match(/await notifyOtherParty\(/g) || []).length).toBe(4);
  });
  it("campaign_lifecycle: request-changes notifies the creator", () => {
    const l = read("backend/campaign_lifecycle.ts");
    expect(l).toContain("type: 'deal_revision_requested'");
    expect(l).toMatch(/deal_revision_requested[\s\S]{0,400}user_id: creatorId|user_id: creatorId[\s\S]{0,200}deal_revision_requested/);
  });
});

describe("v389 · 6. invite email: brand-written text is escaped and contact details masked", () => {
  const s = read("backend/creators_routes.ts");
  it("escapes everything the brand wrote", () => {
    expect(s).toContain("const escH = (v: any)");
    expect(s).toContain("const mailText = (v: any) => escH(maskContactDetails(");
    expect(s).toContain("`<strong>Pitch / Notes:</strong> \"${mailText(formattedPitch)}\"`");
    expect(s).not.toContain("`<strong>Campaign:</strong> ${formattedTitle}`");
    expect(s).toContain("const appUrl = publicSiteUrl();");
  });
});
