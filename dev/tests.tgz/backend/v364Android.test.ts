// v364 (Ravi: "offline app dena hoga — sari screens app mai honi chahiye"): Android app (Capacitor, android-app/),
// its live update route, Firebase (FCM) push and the phone Back button.
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import crypto from "crypto";
import express from "express";
import { readFileSync, existsSync } from "fs";
import { decideAndroidUpdate } from "./appUpdate";
import { buildFcmJwt, buildFcmMessage, fcmConfig, isFcmToken, sendFcm, __resetFcmCache, FCM_PREFIX } from "./fcm";
import { setupPushRoutes } from "./push_routes";

const { privateKey, publicKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 2048 });
const PEM = privateKey.export({ type: "pkcs8", format: "pem" }).toString();
const ACCOUNT = { project_id: "ybex-test", client_email: "push@ybex-test.iam.gserviceaccount.com", private_key: PEM };
const TOKEN = "dGVzdC10b2tlbi1mb3ItZmNt:APA91b" + "A".repeat(120);

describe("v364 — Android live update", () => {
  const latest = { version: "1.0.0-wxyz", file: "bundle-1.0.0-wxyz.zip" };
  it("offers the newer web build; own pause and minimum-version switches", () => {
    expect(decideAndroidUpdate({ version_name: "builtin" }, latest, "https://ybexapp.ai.studio", {} as any)).toEqual({ version: "1.0.0-wxyz", url: "https://ybexapp.ai.studio/ota/bundle-1.0.0-wxyz.zip" });
    expect(decideAndroidUpdate({ version_name: "1.0.0-wxyz" }, latest, "o", {} as any)).toHaveProperty("message");
    expect(decideAndroidUpdate({ version_name: "x" }, latest, "o", { ANDROID_OTA_OFF: "true" } as any)).toEqual({ message: "Updates are paused" });
    // the iPhone switch does not pause Android
    expect(decideAndroidUpdate({ version_name: "x" }, latest, "o", { IOS_OTA_OFF: "true" } as any)).toHaveProperty("version");
    expect(decideAndroidUpdate({ version_name: "x", version_build: "1.0.4" }, latest, "o", { ANDROID_OTA_MIN_BUILD: "1.0.5" } as any)).toEqual({ message: "Please update Ybex from the Play Store" });
    const s = readFileSync("backend/appUpdate.ts", "utf8");
    expect(s).toContain('router.post("/app/android-update"');
    expect(s).toContain('router.post("/app/ios-update"');
  });
});

describe("v364 — FCM", () => {
  beforeEach(() => __resetFcmCache());
  it("reads the service account (raw or base64) and is off without it", () => {
    expect(fcmConfig({} as any)).toBeNull();
    expect(fcmConfig({ FCM_SERVICE_ACCOUNT_JSON: "{bad" } as any)).toBeNull();
    const raw = JSON.stringify(ACCOUNT);
    expect(fcmConfig({ FCM_SERVICE_ACCOUNT_JSON: raw } as any)?.project_id).toBe("ybex-test");
    expect(fcmConfig({ FCM_SERVICE_ACCOUNT_JSON: Buffer.from(raw).toString("base64") } as any)?.client_email).toBe(ACCOUNT.client_email);
  });
  it("signs the Google JWT with RS256 and the messaging scope", () => {
    const jwt = buildFcmJwt(ACCOUNT, 1000);
    const [h, b, sig] = jwt.split(".");
    const claims = JSON.parse(Buffer.from(b, "base64").toString());
    expect(JSON.parse(Buffer.from(h, "base64").toString()).alg).toBe("RS256");
    expect(claims.scope).toBe("https://www.googleapis.com/auth/firebase.messaging");
    expect(claims.exp - claims.iat).toBe(3600);
    expect(crypto.verify("RSA-SHA256", Buffer.from(`${h}.${b}`), publicKey, Buffer.from(sig.replace(/-/g, "+").replace(/_/g, "/"), "base64"))).toBe(true);
  });
  it("message keeps the screen link inside the app, strings only in data", () => {
    const m = buildFcmMessage(TOKEN, { title: "Paid", body: "₹11,700", url: "/earnings", tag: "n-1" });
    expect(m.message.token).toBe(TOKEN);
    expect(m.message.data).toEqual({ url: "/earnings", tag: "n-1" });
    expect(buildFcmMessage(TOKEN, { url: "https://evil.example" }).message.data.url).toBe("/notifications");
    expect(isFcmToken(TOKEN)).toBe(true);
    expect(isFcmToken("ab".repeat(32))).toBe(false); // an Apple token is not an FCM token
  });
  it("sends with one token exchange, then reuses it; UNREGISTERED = gone", async () => {
    const env = { FCM_SERVICE_ACCOUNT_JSON: JSON.stringify(ACCOUNT) } as any;
    const calls: string[] = [];
    let reply: any = { ok: true, status: 200, json: async () => ({ name: "x" }) };
    const f: any = async (url: string, init: any) => {
      calls.push(url);
      if (url.includes("oauth2")) return { ok: true, status: 200, json: async () => ({ access_token: "at-1", expires_in: 3599 }) };
      expect(init.headers.authorization).toBe("Bearer at-1");
      expect(JSON.parse(init.body).message.token).toBe(TOKEN);
      return reply;
    };
    expect((await sendFcm(TOKEN, { title: "Hi" }, { env, fetchImpl: f })).ok).toBe(true);
    reply = { ok: false, status: 404, json: async () => ({ error: { status: "NOT_FOUND", details: [{ errorCode: "UNREGISTERED" }] } }) };
    const r = await sendFcm(TOKEN, { title: "Hi" }, { env, fetchImpl: f });
    expect(r).toMatchObject({ ok: false, gone: true, reason: "UNREGISTERED" });
    expect(calls.filter((u) => u.includes("oauth2")).length).toBe(1);
    expect(calls.filter((u) => u.includes("/v1/projects/ybex-test/messages:send")).length).toBe(2);
    expect((await sendFcm(TOKEN, {}, { env: {} as any, fetchImpl: f })).reason).toBe("FCM not configured");
  });
});

// Fake Supabase good enough for native-register and the sender loop.
function fakeDb(rows: any[]) {
  const q = (table: string) => {
    let filtered = rows.slice();
    let op: string | null = null; let payload: any = null;
    const api: any = {
      select: () => api, limit: () => api, order: () => api,
      in: (_c: string, ids: string[]) => { filtered = filtered.filter((r) => ids.includes(r.user_id)); return api; },
      eq: (c: string, v: any) => {
        filtered = filtered.filter((r) => String(r[c]) === String(v));
        if (op === "delete") for (const r of filtered) rows.splice(rows.indexOf(r), 1);
        return api;
      },
      delete: () => { op = "delete"; return api; },
      upsert: async (row: any) => { payload = row; const i = rows.findIndex((r) => r.endpoint === row.endpoint); if (i >= 0) rows[i] = row; else rows.push(row); return { error: null }; },
      then: (ok: any) => ok({ data: table === "push_subscriptions" ? filtered : [], error: null }),
    };
    void payload;
    return api;
  };
  return { from: q };
}

describe("v364 — push routes with Android phones", () => {
  const saved = process.env.FCM_SERVICE_ACCOUNT_JSON;
  beforeEach(() => { process.env.FCM_SERVICE_ACCOUNT_JSON = JSON.stringify(ACCOUNT); __resetFcmCache(); });
  afterEach(() => { if (saved === undefined) delete process.env.FCM_SERVICE_ACCOUNT_JSON; else process.env.FCM_SERVICE_ACCOUNT_JSON = saved; });

  it("registers an Android token as fcm:<token> (case kept); rejects bad ones", async () => {
    const rows: any[] = [];
    const db = fakeDb(rows);
    const app = express(); app.use(express.json());
    const router = express.Router();
    setupPushRoutes(router, { supabase: db, privilegedSupabase: db, parseAuthUser: async () => ({ user_id: "u1", role: "creator" }) } as any);
    app.use("/api", router);
    const server = app.listen(0); const port = (server.address() as any).port;
    try {
      const post = (body: any) => fetch(`http://127.0.0.1:${port}/api/push/native-register`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) }).then(async (r) => ({ status: r.status, data: await r.json() }));
      const ok = await post({ token: TOKEN, platform: "android" });
      expect(ok.data.ok).toBe(true);
      expect(rows[0]).toMatchObject({ endpoint: FCM_PREFIX + TOKEN, user_id: "u1", p256dh: "fcm", auth: "android" });
      expect((await post({ token: "short", platform: "android" })).status).toBe(400);
      expect((await post({ token: "ab".repeat(32), platform: "android" })).status).toBe(400);
    } finally { server.close(); }
  });

  it("sender routes fcm: rows to FCM and deletes a dead token (file check + helper)", () => {
    const s = readFileSync("backend/push_routes.ts", "utf8");
    expect(s).toContain("startsWith(FCM_PREFIX)");
    expect(s).toContain("sendFcm(String(s.endpoint).slice(FCM_PREFIX.length), payload)");
    expect(s).toMatch(/if \(r\.ok\) sent\+\+;\s*else if \(r\.gone\) await sb\(\)\.from\("push_subscriptions"\)\.delete\(\)\.eq\("endpoint", s\.endpoint\);\s*else console\.error\("\[push\] fcm failed/);
    expect(s).toContain("const enabled = webOn || apnsOn || fcmOn;");
  });
});

describe("v364 — Android app files", () => {
  it("Capacitor config: com.ybex.app, screens inside (../dist/client), https://localhost origin, Android live update", () => {
    const cfg = JSON.parse(readFileSync("android-app/capacitor.config.json", "utf8"));
    expect(cfg.appId).toBe("com.ybex.app");
    expect(cfg.webDir).toBe("../dist/client");
    expect(cfg.server.androidScheme).toBe("https");
    expect(cfg.server.hostname).toBe("localhost");
    expect(cfg.plugins.CapacitorUpdater.updateUrl).toBe("https://ybexapp.ai.studio/api/app/android-update");
    expect(cfg.plugins.SplashScreen.showSpinner).toBe(false);
    const pkg = JSON.parse(readFileSync("android-app/package.json", "utf8"));
    expect(pkg.dependencies["@capacitor/android"]).toBeTruthy();
    expect(pkg.dependencies["@capacitor/push-notifications"]).toBeTruthy();
  });
  it("one-command build script: sign-in link, notification permission, version above the TWA, same key", () => {
    const sh = readFileSync("android-app/scripts/mac-prepare-android.sh", "utf8");
    expect(sh).toContain("npx cap add android");
    expect(sh).toContain('android:scheme="com.ybex.app"');
    expect(sh).toContain("android.permission.POST_NOTIFICATIONS");
    // v388 (Ravi: Play already has 1.0.8 / code 9 — the script must never build a LOWER code): the intent is "above the TWA build (code 4)", so check the number, not "=5".
    expect(Number(/^VERSION_CODE=(\d+)/m.exec(sh)?.[1])).toBeGreaterThanOrEqual(5);
    expect(sh).toContain("my-key-alias");
    expect(existsSync("android-app/README.md")).toBe(true);
    expect(readFileSync(".gitignore", "utf8")).toContain("android-app/android");
  });
  it("Back never traps; native push sends the platform; update route per platform", async () => {
    const native = readFileSync("src/lib/native.js", "utf8");
    expect(native).toContain('"backButton"');
    expect(native).toContain("minimizeApp");
    expect(native).toContain('"android-update" : "ios-update"');
    const { isRootPath } = await import("../src/lib/native.js");
    expect(isRootPath("/dashboard")).toBe(true);
    expect(isRootPath("/dashboard/")).toBe(true);
    expect(isRootPath("/settings")).toBe(false);
    const np = readFileSync("src/lib/nativePush.js", "utf8");
    expect(np).toContain('api.post("push/native-register", { token, platform }');
    expect(np).toContain("ybex_apns_token"); // old iPhone key still read
    const { nativeEndpoint } = await import("../src/lib/nativePush.js");
    expect(nativeEndpoint("android", "AbC")).toBe("fcm:AbC");
    expect(nativeEndpoint("ios", "AB")).toBe("apns:ab");
  });
  it("Android app origin is allowed by the server CORS (localhost)", () => {
    expect(readFileSync("backend/server.ts", "utf8")).toContain('"ybexapp.ai.studio", "localhost", "127.0.0.1"');
  });
});
