// v377 (Ravi, "Diwali Challenge v2: Easy Entry"): any reel of the creator's own, three tags in the caption, admin review
// (Pending / Approved / Rejected), ₹50 recharge for the first 300 creators (one each), "signed up, no reel yet" list.
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import express from "express";
import type { AddressInfo } from "net";
import { setupChallengeRoutes, liveStatsFor, rechargeOrder } from "./challenge_routes";
import { STARTS_AT, captionChecks, qualifies, RECHARGE_SLOTS } from "../src/lib/diwaliChallenge";

type Row = Record<string, any>;
function fakeSupabase(opts: { noLedger?: boolean; maxRows?: number } = {}) {
  const tables: Record<string, Row[]> = { creator_profiles: [], ybex_ephemeral: [], users: [] };
  const calls: string[] = [];
  function q(table: string) {
    let rows = () => tables[table] || [];
    const filters: Array<(r: Row) => boolean> = [];
    let range: [number, number] | null = null;
    let lim = Infinity;
    let op: "select" | "update" | "upsert" = "select";
    let patch: any = null;
    let single = false;
    const missing = () => opts.noLedger && table === "ybex_ephemeral";
    const api: any = {
      select() { return api; },
      not(col: string, _o: string, _v: any) { filters.push((r) => r[col] != null); return api; },
      gte(col: string, v: any) { filters.push((r) => String(r[col]) >= String(v)); return api; },
      eq(col: string, v: any) { filters.push((r) => String(r[col]) === String(v)); return api; },
      in(col: string, vs: any[]) { filters.push((r) => vs.map(String).includes(String(r[col]))); return api; },
      like(col: string, pat: string) { const p = pat.replace(/%$/, ""); filters.push((r) => String(r[col]).startsWith(p)); return api; },
      range(a: number, b: number) { range = [a, b]; return api; },
      order() { return api; },
      limit(n: number) { lim = n; return api; },
      maybeSingle() { single = true; return api; },
      update(p: any) { op = "update"; patch = p; return api; },
      upsert(p: any) { op = "upsert"; patch = p; return api; },
      then(res: any, rej: any) {
        try {
          calls.push(`${op}:${table}`);
          if (missing()) return Promise.resolve({ data: null, error: { message: "relation \"ybex_ephemeral\" does not exist", code: "42P01" } }).then(res, rej);
          if (op === "upsert") {
            const i = tables[table].findIndex((r) => r.key === patch.key);
            if (i >= 0) tables[table][i] = JSON.parse(JSON.stringify(patch)); else tables[table].push(JSON.parse(JSON.stringify(patch)));
            return Promise.resolve({ data: null, error: null }).then(res, rej);
          }
          let out = rows().filter((r) => filters.every((f) => f(r)));
          if (op === "update") { out.forEach((r) => Object.assign(r, JSON.parse(JSON.stringify(patch)))); return Promise.resolve({ data: null, error: null }).then(res, rej); }
          if (range) out = out.slice(range[0], range[1] + 1);
          out = out.slice(0, Math.min(lim, opts.maxRows ?? Infinity)).map((r) => JSON.parse(JSON.stringify(r)));
          return Promise.resolve({ data: single ? (out[0] || null) : out, error: null }).then(res, rej);
        } catch (e) { return Promise.reject(e).then(res, rej); }
      },
    };
    return api;
  }
  return { client: { from: (t: string) => q(t) }, tables, calls };
}


const USERS: Record<string, any> = {
  c1: { user_id: "c1", role: "creator", onboarded: true, name: "Ravi", email: "r@x.in" },
  c2: { user_id: "c2", role: "creator", onboarded: false, name: "@riya.reels", email: "riya@x.in", phone: "+919876511111" },
  admin: { user_id: "a1", role: "admin" },
};
let server: any; let base = ""; let fake: ReturnType<typeof fakeSupabase>; let igCalls: string[] = []; let igMedia: any = {};
async function start(opts: any = {}) {
  fake = fakeSupabase(opts);
  fake.tables.creator_profiles.push({ user_id: "c1", name: "Ravi", instagram: "elite_ravi", portfolio: [] });
  fake.tables.creator_profiles.push({ user_id: "c2", name: "@riya.reels", instagram: "riya.reels", portfolio: [] });
  const after = new Date(STARTS_AT + 3600_000).toISOString();
  fake.tables.users.push({ user_id: "c1", role: "creator", name: "Ravi", email: "r@x.in", phone: "+919800000001", created_at: after });
  fake.tables.users.push({ user_id: "c2", role: "creator", name: "@riya.reels", email: "riya@x.in", phone: "+919876511111", created_at: after });
  fake.tables.users.push({ user_id: "c3", role: "creator", name: "@noreel", email: "phone-919800000003@ybex.io", phone: "+919800000003", created_at: after });
  fake.tables.users.push({ user_id: "old", role: "creator", name: "Old", email: "o@x.in", phone: "", created_at: new Date(STARTS_AT - 86400_000).toISOString() });
  const app = express(); app.use(express.json());
  const router = express.Router();
  setupChallengeRoutes(router, { supabase: null, privilegedSupabase: fake.client, parseAuthUser: async (req: any) => USERS[String(req.headers["x-u"] || "")] || null,
    fetchIg: async (h: string) => { igCalls.push(h); if (igMedia.__throw) throw igMedia.__throw; return { media: igMedia[h] || [] }; } });
  app.use("/api", router);
  await new Promise<void>((r) => { server = app.listen(0, () => r()); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}/api`;
}
const call = async (path: string, who = "", body?: any) => {
  const r = await fetch(base + path, { method: body ? "POST" : "GET", headers: { "content-type": "application/json", "x-u": who }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: await r.json() };
};
const reel = (c: string) => `https://www.instagram.com/reel/${c}/`;
const profileOf = (uid: string) => fake.tables.creator_profiles.find((r) => r.user_id === uid)!;
const saveFor = (uid: string, items: any[]) => { profileOf(uid).portfolio = items.map((i) => JSON.stringify(i)); };
async function enter(uid: string, id: string, code: string) {
  const it = { id, content_url: reel(code) };
  const s = await call("/challenge/stamp", uid, { items: [it] });
  expect(s.status).toBe(200);
  const prev = (profileOf(uid).portfolio || []).map((x: any) => (typeof x === "string" ? JSON.parse(x) : x));
  saveFor(uid, [...prev, { ...it, ...s.body.stamps[id] }]);
}

beforeEach(() => { vi.useFakeTimers({ toFake: ["Date"] }); vi.setSystemTime(new Date(STARTS_AT + 86400_000)); igCalls = []; igMedia = {}; });
afterEach(async () => { vi.useRealTimers(); if (server) await new Promise((r) => server.close(r)); server = null; });

beforeEach(() => { vi.useFakeTimers({ toFake: ["Date"] }); vi.setSystemTime(new Date(STARTS_AT + 86400_000)); igCalls = []; igMedia = {}; });
afterEach(async () => { vi.useRealTimers(); if (server) await new Promise((r) => server.close(r)); server = null; });

describe("v377 · rule: any reel, three tags", () => {
  it("captionChecks needs @ybex.in, the exact #Ybex and #YbexDiwaliChallenge", () => {
    expect(captionChecks("my dance 💃 @ybex.in #Ybex #YbexDiwaliChallenge").ok).toBe(true);
    expect(captionChecks("@ybex.in #YbexDiwaliChallenge").ybex).toBe(false); // #Ybex inside the longer tag doesn't count
    expect(captionChecks("#ybex #ybexdiwalichallenge")).toMatchObject({ mention: false, ok: false });
    expect(captionChecks("mail ravi@ybex.in #Ybex #YbexDiwaliChallenge").mention).toBe(false);
    expect(captionChecks("#Ybexers @ybex.in #YbexDiwaliChallenge").ybex).toBe(false);
    expect(qualifies("Nykaa", ["no tags"])).toBe(true);
  });
  it("live numbers carry the tag checks and the posted date", () => {
    const out = liveStatsFor([{ content_url: reel("AAAAA1") }], [{ permalink: reel("AAAAA1"), views: 10, likes: 2, caption: "@ybex.in #Ybex", at: new Date(STARTS_AT - 3600_000).toISOString() }], "t");
    expect(out.AAAAA1).toMatchObject({ caption_ok: false, tags: { mention: true, ybex: true, challenge: false }, posted_ok: false });
  });
});

describe("v377 · review + ₹50 recharge (real router over HTTP)", () => {
  it("entries start Pending; rejected ones don't count or take a recharge place; approve → tick 'sent'", async () => {
    await start();
    await enter("c1", "pf_1", "RAVI001");
    vi.setSystemTime(new Date(STARTS_AT + 86400_000 + 60_000));
    await enter("c2", "pf_9", "RIYA001");
    let pub = await call("/challenge/public");
    expect(pub.body).toMatchObject({ entries: 2, creators: 2, recharge_left: RECHARGE_SLOTS - 2, recharge_slots: RECHARGE_SLOTS });

    let list = await call("/admin/challenge/entries?fresh=1", "admin");
    expect(list.body.entries.map((e: any) => [e.user_id, e.status, e.recharge_place])).toEqual([["c1", "pending", 1], ["c2", "pending", 2]]);
    expect(list.body.entries.find((e: any) => e.user_id === "c2").phone).toBe("+919876511111");

    // only admins review
    expect((await call("/admin/challenge/review", "c1", { user_id: "c1", item_id: "pf_1", status: "approved" })).status).toBe(403);
    expect((await call("/admin/challenge/review", "admin", { user_id: "c1", item_id: "pf_1", status: "approved" })).status).toBe(200);
    expect((await call("/admin/challenge/review", "admin", { user_id: "c1", item_id: "pf_1", status: "winner" })).status).toBe(400);
    // c1 rejected → c2 moves up to place 1
    await call("/admin/challenge/review", "admin", { user_id: "c1", item_id: "pf_1", status: "rejected" });
    list = await call("/admin/challenge/entries?fresh=1", "admin");
    expect(list.body.entries.map((e: any) => [e.user_id, e.status, e.recharge_place])).toEqual([["c1", "rejected", null], ["c2", "pending", 1]]);
    pub = await call("/challenge/public");
    expect(pub.body).toMatchObject({ entries: 1, creators: 1, recharge_left: RECHARGE_SLOTS - 1 });

    await call("/admin/challenge/review", "admin", { user_id: "c2", item_id: "pf_9", status: "approved" });
    expect((await call("/admin/challenge/recharge", "c2", { user_id: "c2", sent: true })).status).toBe(403);
    const t = await call("/admin/challenge/recharge", "admin", { user_id: "c2", sent: true });
    expect(t.body.recharge_sent_at).toBeTruthy();
    list = await call("/admin/challenge/entries?fresh=1", "admin");
    expect(list.body.entries.find((e: any) => e.user_id === "c2")).toMatchObject({ status: "approved", recharge_place: 1 });
    expect(list.body.entries.find((e: any) => e.user_id === "c2").recharge_sent_at).toBeTruthy();
    const me = await call("/challenge/me", "c2");
    expect(me.body.recharge).toMatchObject({ place: 1, left: RECHARGE_SLOTS - 1 });
    expect(me.body.recharge.sent_at).toBeTruthy();
    // a creator's own save can't change the review (it lives in the server ledger)
    const prev = (profileOf("c1").portfolio || []).map((x: any) => JSON.parse(x));
    saveFor("c1", prev.map((x: any) => ({ ...x, status: "approved" })));
    list = await call("/admin/challenge/entries?fresh=1", "admin");
    expect(list.body.entries.find((e: any) => e.user_id === "c1").status).toBe("rejected");
  });
  it("one recharge place per creator, max 300", () => {
    const list = Array.from({ length: 305 }, (_, i) => ({ user_id: `u${i}`, item_id: "a", at: new Date(STARTS_AT + i * 1000).toISOString(), status: "pending" }));
    list.push({ user_id: "u0", item_id: "b", at: new Date(STARTS_AT + 999_999).toISOString(), status: "pending" }); // 2nd reel, same creator
    const order = rechargeOrder(list);
    expect(order.size).toBe(RECHARGE_SLOTS);
    expect(order.get("u0")).toBe(1);
    expect(order.has("u304")).toBe(false);
  });
  it("'signed up, no reel yet' lists creators who joined since the start without an entry", async () => {
    await start();
    await enter("c1", "pf_1", "RAVI001");
    expect((await call("/admin/challenge/no-reel", "c1")).status).toBe(403);
    const r = await call("/admin/challenge/no-reel", "admin");
    const ids = r.body.creators.map((x: any) => x.user_id).sort();
    expect(ids).toEqual(["c2", "c3"]);
    const c3 = r.body.creators.find((x: any) => x.user_id === "c3");
    expect(c3).toMatchObject({ phone: "+919800000003", email: "" }); // never-mailed phone placeholder hidden
  });
});

describe("v377 · fixes: Google sign-in stays on ybexmedia.in; silent app update", () => {
  it("redirect_uri follows the public host the Cloudflare Worker forwards (only known hosts)", async () => {
    const { setupOAuthRoutes } = await import("./oauth_routes");
    process.env.GOOGLE_CLIENT_ID = "cid.apps.googleusercontent.com";
    const app = express();
    const router = express.Router();
    setupOAuthRoutes(router, { supabase: null, privilegedSupabase: null, getDb: () => ({}), saveDb: () => {} } as any);
    app.use("/api", router);
    const srv: any = await new Promise((r) => { const s = app.listen(0, () => r(s)); });
    const b = `http://127.0.0.1:${(srv.address() as AddressInfo).port}/api`;
    const uri = async (fwd?: string) => {
      const res = await fetch(`${b}/auth/oauth/url?provider=google&role=creator`, { headers: fwd ? { "x-forwarded-host": fwd } : {} });
      return new URL((await res.json()).url).searchParams.get("redirect_uri");
    };
    try {
      expect(await uri("ybexmedia.in")).toBe("https://ybexmedia.in/api/auth/oauth/google/callback");
      expect(await uri("www.ybexmedia.in")).toBe("https://www.ybexmedia.in/api/auth/oauth/google/callback");
      expect(await uri("evil.example.com")).toMatch(/^http:\/\/127\.0\.0\.1:\d+\/api\/auth\/oauth\/google\/callback$/); // not trusted → real host
      expect(await uri()).toMatch(/127\.0\.0\.1/);
    } finally { srv.close(); }
  });
  it("no 'A new version of Ybex is ready' toast — the update waits silently", async () => {
    const fs = await import("fs");
    const src = fs.readFileSync(require("path").resolve(__dirname, "../src/index.jsx"), "utf8");
    expect(src).not.toContain("A new version of Ybex is ready");
    expect(src).toContain("onNeedRefresh()");
  });
});
