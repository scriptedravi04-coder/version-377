import { describe, it, expect } from "vitest";
import fs from "fs";
import { approvedByAdmin, awaitingReview, visibleOnExplore } from "./exploreGate";
import { isShowableCreator } from "./creatorHomePicks";
import { markUnderReview } from "./creatorReviewGate";
import { approvedByAdmin as approvedByAdminUi, visibleCreators } from "../src/lib/visibleCreators.js";

const NEW = "2026-10-19T14:52:41Z";
const OLD = "2026-09-01T10:00:00Z";
const base = { name: "Sakshi Matta", instagram_handle: "hsyen", is_claimed: true };

describe("v357 · signed-up creators wait for the admin before Explore", () => {
  it("'approved' only by the DB default (new, claimed, never reviewed) → waitlist, not Explore", () => {
    const row = { ...base, profile_status: "approved", reviewed_at: null, created_at: NEW };
    expect(approvedByAdmin(row)).toBe(false);
    expect(awaitingReview(row)).toBe(true);
    expect(visibleOnExplore(row)).toBe(false);
    expect(isShowableCreator(row)).toBe(false);
    expect(approvedByAdminUi(row)).toBe(false);
    expect(visibleCreators([row])).toHaveLength(0);
  });

  it("approved by the admin (reviewed_at) → Explore", () => {
    const row = { ...base, profile_status: "approved", reviewed_at: "2026-10-20T08:00:00Z", created_at: NEW };
    expect(visibleOnExplore(row)).toBe(true);
    expect(awaitingReview(row)).toBe(false);
    expect(isShowableCreator(row)).toBe(true);
    expect(visibleCreators([row])).toHaveLength(1);
  });

  it("unclaimed form profiles and creators from before the gate are unchanged", () => {
    expect(visibleOnExplore({ ...base, is_claimed: false, profile_status: "approved", created_at: NEW })).toBe(true);
    expect(visibleOnExplore({ ...base, profile_status: "approved", created_at: OLD })).toBe(true);
    expect(visibleCreators([{ ...base, profile_status: "approved", created_at: OLD }])).toHaveLength(1);
  });

  it("under_review stays on the waitlist, rejected / deleted never", () => {
    expect(awaitingReview({ ...base, profile_status: "under_review", created_at: NEW })).toBe(true);
    expect(visibleOnExplore({ ...base, profile_status: "under_review", created_at: NEW })).toBe(false);
    expect(awaitingReview({ ...base, profile_status: "rejected", created_at: NEW })).toBe(false);
    expect(awaitingReview({ ...base, profile_status: "approved", created_at: NEW, is_deleted: true })).toBe(false);
  });

  it("markUnderReview only touches an unreviewed 'approved' row", async () => {
    const calls: any[] = [];
    const q: any = { update: (v: any) => { calls.push(["update", v]); return q; }, eq: (k: string, v: any) => { calls.push(["eq", k, v]); return q; }, is: (k: string, v: any) => { calls.push(["is", k, v]); return Promise.resolve({}); } };
    const client = { from: () => q };
    const local = { creator_profiles: [{ user_id: "u1", profile_status: "approved" }, { user_id: "u2", profile_status: "approved", reviewed_at: "x" }] };
    await markUnderReview(client, () => local, "u1");
    expect(calls).toContainEqual(["update", { profile_status: "under_review" }]);
    expect(calls).toContainEqual(["eq", "profile_status", "approved"]);
    expect(calls).toContainEqual(["is", "reviewed_at", null]);
    expect(local.creator_profiles[0].profile_status).toBe("under_review");
    await markUnderReview(null, () => local, "u2");
    expect(local.creator_profiles[1].profile_status).toBe("approved");
  });

  it("wiring: waitlist lists them, guard runs before the locked creators routes, admin edit = review", () => {
    const w = fs.readFileSync("backend/admin_waitlist_routes.ts", "utf8");
    expect(w).toContain("cp.profile_status !== 'under_review' && !awaitingReview(cp)");
    const server = fs.readFileSync("backend/server.ts", "utf8");
    expect(server.indexOf("setupCreatorReviewGate(router")).toBeGreaterThan(0);
    expect(server.indexOf("setupCreatorReviewGate(router")).toBeLessThan(server.indexOf("setupCreatorsRoutes(app, router"));
    expect(fs.readFileSync("backend/admin_logs_creators_routes.ts", "utf8")).toContain("cpUpdatePayload.reviewed_at");
    expect(fs.readFileSync("backend/auth_routes.ts", "utf8")).toContain('awaitingReview(cp) ? "under_review"');
    expect(fs.readFileSync("src/components/admin/CreatorProfileEditModal.jsx", "utf8")).toContain("realStatus(cp)");
  });
});
