// v373 deep test (Ravi: "deep black box and white box testing, chote se chota bug fix"): fixes found while playing the
// Diwali Challenge as a creator on the real server — paged ledger, one stamp at a time, live numbers for judging.
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import express from "express";
import type { AddressInfo } from "net";
import { setupChallengeRoutes, liveStatsFor, LEDGER_PREFIX } from "./challenge_routes";
import { STARTS_AT, CHALLENGE_ID } from "../src/lib/diwaliChallenge";

type Row = Record<string, any>;
function fakeSupabase(opts: { noLedger?: boolean; maxRows?: number } = {}) {
  const tables: Record<string, Row[]> = { creator_profiles: [], ybex_ephemeral: [] };
  const calls: string[] = [];
  function q(table: string) {
    let rows = () => tables[table] || [];
    const filters: Array<(r: Row) => boolean> = [];
    let range: [number, number] | null = null;
    let lim = Infinity;
    let op: "select" | "update" | "upsert" = "select";
    let patch: any = null;
    let single = false;
    const missing = () => opts.noLedger && table === "ybex_ephemeral";
    const api: any = {
      select() { return api; },
      not(col: string, _o: string, _v: any) { filters.push((r) => r[col] != null); return api; },
      eq(col: string, v: any) { filters.push((r) => String(r[col]) === String(v)); return api; },
      in(col: string, vs: any[]) { filters.push((r) => vs.map(String).includes(String(r[col]))); return api; },
      like(col: string, pat: string) { const p = pat.replace(/%$/, ""); filters.push((r) => String(r[col]).startsWith(p)); return api; },
      range(a: number, b: number) { range = [a, b]; return api; },
      order() { return api; },
      limit(n: number) { lim = n; return api; },
      maybeSingle() { single = true; return api; },
      update(p: any) { op = "update"; patch = p; return api; },
      upsert(p: any) { op = "upsert"; patch = p; return api; },
      then(res: any, rej: any) {
        try {
          calls.push(`${op}:${table}`);
          if (missing()) return Promise.resolve({ data: null, error: { message: "relation \"ybex_ephemeral\" does not exist", code: "42P01" } }).then(res, rej);
          if (op === "upsert") {
            const i = tables[table].findIndex((r) => r.key === patch.key);
            if (i >= 0) tables[table][i] = JSON.parse(JSON.stringify(patch)); else tables[table].push(JSON.parse(JSON.stringify(patch)));
            return Promise.resolve({ data: null, error: null }).then(res, rej);
          }
          let out = rows().filter((r) => filters.every((f) => f(r)));
          if (op === "update") { out.forEach((r) => Object.assign(r, JSON.parse(JSON.stringify(patch)))); return Promise.resolve({ data: null, error: null }).then(res, rej); }
          if (range) out = out.slice(range[0], range[1] + 1);
          out = out.slice(0, Math.min(lim, opts.maxRows ?? Infinity)).map((r) => JSON.parse(JSON.stringify(r)));
          return Promise.resolve({ data: single ? (out[0] || null) : out, error: null }).then(res, rej);
        } catch (e) { return Promise.reject(e).then(res, rej); }
      },
    };
    return api;
  }
  return { client: { from: (t: string) => q(t) }, tables, calls };
}


const USERS: Record<string, any> = {
  c1: { user_id: "c1", role: "creator", onboarded: true, name: "Ravi", email: "r@x.in" },
  admin: { user_id: "a1", role: "admin" },
};
let server: any; let base = ""; let fake: ReturnType<typeof fakeSupabase>; let igCalls: string[] = []; let igMedia: any = {};
async function start(opts: any = {}) {
  fake = fakeSupabase(opts);
  fake.tables.creator_profiles.push({ user_id: "c1", name: "Ravi", instagram: "elite_ravi", portfolio: [] });
  const app = express(); app.use(express.json());
  const router = express.Router();
  setupChallengeRoutes(router, { supabase: null, privilegedSupabase: fake.client, parseAuthUser: async (req: any) => USERS[String(req.headers["x-u"] || "")] || null,
    fetchIg: async (h: string) => { igCalls.push(h); if (igMedia.__throw) throw igMedia.__throw; return { media: igMedia[h] || [] }; } });
  app.use("/api", router);
  await new Promise<void>((r) => { server = app.listen(0, () => r()); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}/api`;
}
const call = async (path: string, who = "", body?: any) => {
  const r = await fetch(base + path, { method: body ? "POST" : "GET", headers: { "content-type": "application/json", "x-u": who }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, body: await r.json() };
};
const reel = (c: string) => `https://www.instagram.com/reel/${c}/`;
const profile = () => fake.tables.creator_profiles.find((r) => r.user_id === "c1")!;
const saveWith = (items: any[]) => { profile().portfolio = items.map((i) => JSON.stringify(i)); };

beforeEach(() => { vi.useFakeTimers({ toFake: ["Date"] }); vi.setSystemTime(new Date(STARTS_AT + 86400_000)); igCalls = []; igMedia = {}; });
afterEach(async () => { vi.useRealTimers(); await new Promise((r) => server.close(r)); });

describe("v373 · stamps", () => {
  it("two stamps at the same moment can't hand out a 4th entry", async () => {
    await start();
    const items = [1, 2, 3, 4].map((i) => ({ id: `pf_${i}`, content_url: reel(`ZZZZZ${i}`) }));
    const rs = await Promise.all([call("/challenge/stamp", "c1", { items: items.slice(0, 2) }), call("/challenge/stamp", "c1", { items: items.slice(2, 4) })]);
    const stamped = rs.filter((r) => r.status === 200).reduce((a, r) => a + Object.keys(r.body.stamps).length, 0);
    expect(stamped).toBeLessThanOrEqual(3);
    expect(rs.some((r) => r.body.code === "LIMIT")).toBe(true);
  });
  it("a stamp handed out but not saved yet still holds its slot; asking again for the same reel is fine", async () => {
    await start();
    const a = await call("/challenge/stamp", "c1", { items: [{ id: "pf_1", content_url: reel("AAAAA1") }, { id: "pf_2", content_url: reel("AAAAA2") }] });
    expect(a.status).toBe(200);
    const again = await call("/challenge/stamp", "c1", { items: [{ id: "pf_1", content_url: reel("AAAAA1") }] });
    expect(again.status).toBe(200); // retry after a failed save
    const two = await call("/challenge/stamp", "c1", { items: [{ id: "pf_3", content_url: reel("AAAAA3") }, { id: "pf_4", content_url: reel("AAAAA4") }] });
    expect(two.body.code).toBe("LIMIT");
    vi.setSystemTime(new Date(STARTS_AT + 86400_000 + 16 * 60_000)); // never saved → slot free after 15 min
    const later = await call("/challenge/stamp", "c1", { items: [{ id: "pf_3", content_url: reel("AAAAA3") }, { id: "pf_4", content_url: reel("AAAAA4") }] });
    expect(later.status).toBe(200);
  });
  it("an existing portfolio reel can be entered (same id) and counts", async () => {
    await start();
    const item = { id: "pf_old", content_url: reel("OLDREEL1"), brand_name: "Ybex" };
    saveWith([item]);
    const s = await call("/challenge/stamp", "c1", { items: [item] });
    expect(s.status).toBe(200);
    saveWith([{ ...item, ...s.body.stamps.pf_old }]);
    const me = await call("/challenge/me", "c1");
    expect(me.body.entries).toHaveLength(1);
  });
});

describe("v373 · ledger has more than 1,000 rows", () => {
  it("reads every page (Supabase gives max 1,000 rows per request)", async () => {
    await start({ maxRows: 1000 });
    for (let i = 0; i < 1500; i++) fake.tables.ybex_ephemeral.push({ key: `${LEDGER_PREFIX}u${String(i).padStart(4, "0")}`, value: { remind: true, contact: { name: `C${i}` } } });
    const r = await call("/admin/challenge/reminders", "admin");
    expect(r.body.reminders.length).toBe(1500);
  });
});

describe("v373 · live numbers for judging", () => {
  it("liveStatsFor matches by shortcode, checks the hashtag, marks missing reels", () => {
    const out = liveStatsFor([{ content_url: reel("AAAAA1"), views: 10 }, { content_url: reel("GONE001"), views: 7 }],
      [{ permalink: "https://www.instagram.com/elite_ravi/reel/AAAAA1/", views: 9000, likes: 400, caption: "Diwali! @ybex.in #Ybex #YbexDiwaliChallenge" }], "t"); // v377: all three tags
    expect(out.AAAAA1).toMatchObject({ views: 9000, likes: 400, caption_ok: true, found: true });
    expect(out.GONE001).toMatchObject({ views: 7, found: false });
  });
  it("Refresh numbers → admin list shows live views; creator's save can't undo them; token error stops", async () => {
    await start();
    const s = await call("/challenge/stamp", "c1", { items: [{ id: "pf_1", content_url: reel("AAAAA1") }] });
    saveWith([{ id: "pf_1", content_url: reel("AAAAA1"), views: 100, likes: 5, ...s.body.stamps.pf_1 }]);
    igMedia.elite_ravi = [{ permalink: reel("AAAAA1"), views: 52000, likes: 2100, caption: "no tag here" }];
    expect((await call("/admin/challenge/refresh-stats", "c1", { offset: 0 })).status).toBe(403);
    const r = await call("/admin/challenge/refresh-stats", "admin", { offset: 0 });
    expect(r.body).toMatchObject({ ok: true, total: 1, done: true, updated: 1 });
    expect(igCalls).toEqual(["elite_ravi"]);
    const list = (await call("/admin/challenge/entries?fresh=1", "admin")).body.entries;
    expect(list[0]).toMatchObject({ views: 52000, likes: 2100, caption_ok: false });
    // the creator saves again with the old numbers — live ones stay
    saveWith([{ id: "pf_1", content_url: reel("AAAAA1"), views: 100, likes: 5, ...s.body.stamps.pf_1 }]);
    expect((await call("/admin/challenge/entries?fresh=1", "admin")).body.entries[0].views).toBe(52000);
    igMedia.__throw = { error: { code: 190, message: "Error validating access token" } };
    const t = await call("/admin/challenge/refresh-stats", "admin", { offset: 0 });
    expect(t.status).toBe(502); expect(t.body.code).toBe("TOKEN");
  });
});
