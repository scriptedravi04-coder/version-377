// v366 money fixes (Ravi: "ye dono bhi fix karo, baaki jo pending hai unhe bhi work karo"; locked-file OK: "haan, locked
// files mein ye fee change kar do"). Same black-box harness as v365BackboneE2E (copied — that file's helpers aren't
// exported): the REAL routes on a realistic in-memory Supabase + a stateful fake Razorpay. Exact rupees everywhere.
import { describe, it, expect, vi, beforeEach } from "vitest";
import express from "express";
import crypto from "crypto";

// ───────────────────────── fake Razorpay (stateful) ─────────────────────────
const rz = vi.hoisted(() => {
  const orders = new Map<string, any>();
  let n = 0;
  const flags = { failCreate: false };
  return {
    orders, flags,
    reset() { orders.clear(); n = 0; flags.failCreate = false; },
    api: {
      orders: {
        create: async (o: any) => { if (flags.failCreate) throw new Error("razorpay down"); const id = `order_T${++n}`; const row = { id, amount: o.amount, currency: o.currency, notes: o.notes || {}, status: "created", amount_paid: 0 }; orders.set(id, row); return { ...row }; },
        fetch: async (id: string) => { const o = orders.get(id); if (!o) throw new Error("not found"); return { ...o }; },
        fetchPayments: async (id: string) => ({ items: orders.get(id)?.status === "paid" ? [{ id: `pay_${id}`, status: "captured" }] : [] }),
      },
      payments: { fetch: async (id: string) => ({ id, status: "captured" }) },
    },
  };
});
vi.mock("./helpers", async (importOriginal) => {
  const orig: any = await importOriginal();
  return { ...orig, getRazorpay: () => rz.api };
});

import { setupPaymentRoutes } from "./payment_routes";
import { __resetFeeConfigCache, claimBrandCoupon, confirmBrandCoupon } from "./brandFee";
import fs from "fs";
import path from "path";
const read = (f: string) => fs.readFileSync(path.join(__dirname, "..", f), "utf8");

// ───────────────────────── realistic fake Supabase ─────────────────────────
const LIVE: Record<string, string> = {
  platform_fee_config: "id,threshold_amount,below_threshold_rate,above_threshold_rate,gst_rate,created_at,updated_at,platform_gst_registered,platform_gstin,ugc_commission_pct,withdrawal_min_limit,auto_payout_threshold,offer_mode,offer_fee_pct,offer_label,offer_promo_line,offer_line_until,brand_markup_pct,creator_deduction_pct,agency_markup_pct,agency_deduction_pct,payout_freeze_all,min_campaign_budget,max_campaign_budget,withdrawal_fee_rate,dispute_refund_window_days,fee_model,creator_fee_pct,brand_fee_pct",
  coupons: "id,code,type,discount_amount,applies_to,usage_limit,used_count,per_user_limit,valid_from,valid_until,min_campaign_value,status,created_by,created_at,updated_at,override_fee_rate,applies_to_first_n_payouts,auto_apply",
  coupon_redemptions: "id,coupon_id,user_id,campaign_id,deal_id,ugc_order_id,discount_applied,redeemed_at,payouts_consumed",
  deals: "id,application_id,campaign_id,creator_id,brand_id,agreed_amount,is_barter,barter_details,deliverables,content_deadline,go_live_date,revision_count,revisions_used,posting_requirements,agreement_signed_creator,agreement_signed_brand,agreement_signed_at,status,created_at,updated_at,escrow_hold,escrow_hold_reason,escrow_hold_by_admin_id,escrow_hold_at,promised_reach,delivered_reach,delivered_reach_source,delivered_reach_updated_at,performance_score,performance_tier,on_time_submission,brand_rating",
  chat_threads: "id,deal_id,campaign_id,creator_id,brand_id,status,agreed_amount,deliverables,deadline,revision_count,agreement_signed_creator,agreement_signed_brand,agreement_signed_at,created_at,updated_at,flow_state,campaign_deal_id,ugc_order_id_text,is_ugc,ugc_order_id",
  ugc_briefs: "id,brand_id,title,product_name,product_description,budget,max_creators,claimed_count,status,detailed_requirements,sample_content_url,dos,donts,deliverable_type,video_duration,created_at,brand_name,relisted_at,relist_count,is_priority,delivery_hours,razorpay_order_id",
  transactions: "id,deal_id,creator_id,gross_amount,platform_fee_amount,creator_net_amount,gst_amount,zaakpay_order_id,status,created_at,payout_type,admin_action_by,admin_action_note,ugc_order_id,refund_amount,refund_status,refund_reason,refund_reference,refunded_at,refunded_by,correct_fee_amount,fee_correction_note,payout_status,payout_reference,expected_payout_date,payout_completed_at,payout_completed_by,campaign_deal_id,ugc_order_id_text,brief_id,brand_id,escrow_hold,updated_at,notes,payout_requested,payout_request_count,payout_request_notes,last_payout_requested_at,razorpay_payment_id,brand_fee_pct,brand_fee_amount,brand_fee_gst,brand_paid_amount,coupon_code",
};
const COLS: Record<string, Set<string>> = Object.fromEntries(Object.entries(LIVE).map(([k, v]) => [k, new Set(v.split(","))]));
const unescape = (v: string) => String(v).replace(/\\([\\%_])/g, "$1");
const likeRe = (pat: string) => new RegExp("^" + String(pat).replace(/\\([\\%_])|([.*+?^${}()|[\]\\])|(%)|(_)/g, (_m, esc, rx, pc, us) => esc ? esc.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") : rx ? "\\" + rx : pc ? ".*" : us ? "." : "") + "$", "i");

function fakeDb(seed: Record<string, any[]>) {
  const t: Record<string, any[]> = JSON.parse(JSON.stringify(seed));
  const log: { table: string; op: string; row?: any; patch?: any }[] = [];
  const badCol = (table: string, row: any) => {
    const allowed = COLS[table];
    if (!allowed) return null;
    for (const k of Object.keys(row || {})) if (!allowed.has(k)) return { message: `Could not find the '${k}' column of '${table}' in the schema cache`, code: "PGRST204" };
    return null;
  };
  const from = (table: string) => {
    if (!t[table]) t[table] = [];
    const filters: Array<(r: any) => boolean> = [];
    let op = "select"; let patch: any = null; let ins: any[] = []; let head = false; let countOn = false;
    let lim = Infinity; let order: { c: string; asc: boolean } | null = null;
    const match = () => t[table].filter((r) => filters.every((f) => f(r)));
    const q: any = {
      select: (_c?: string, o?: any) => { if (o?.head) head = true; if (o?.count) countOn = true; return q; },
      eq: (c: string, v: any) => { filters.push((r) => String(r[c]) === String(v)); return q; },
      neq: (c: string, v: any) => { filters.push((r) => String(r[c]) !== String(v)); return q; },
      gt: (c: string, v: any) => { filters.push((r) => Number(r[c]) > Number(v)); return q; },
      gte: (c: string, v: any) => { filters.push((r) => r[c] >= v); return q; },
      lte: (c: string, v: any) => { filters.push((r) => r[c] <= v); return q; },
      in: (c: string, vs: any[]) => { filters.push((r) => (vs || []).map(String).includes(String(r[c]))); return q; },
      is: (c: string, v: any) => { filters.push((r) => (v === null ? r[c] == null : r[c] === v)); return q; },
      not: () => q, filter: () => q, match: () => q,
      ilike: (c: string, v: string) => { const re = likeRe(v); filters.push((r) => re.test(String(r[c] ?? ""))); return q; },
      or: (expr: string) => {
        const parts = String(expr).split(",").map((p) => p.split("."));
        filters.push((r) => parts.some(([c, o, ...v]) => { const val = v.join("."); if (o === "eq") return String(r[c]) === val; if (o === "is") return val === "null" ? r[c] == null : String(r[c]) === val; return false; }));
        return q;
      },
      order: (c: string, o?: any) => { order = { c, asc: o?.ascending !== false }; return q; },
      limit: (n: number) => { lim = n; return q; },
      range: (a: number, b: number) => { lim = b - a + 1; return q; },
      insert: (rows: any) => { op = "insert"; ins = Array.isArray(rows) ? rows : [rows]; return q; },
      upsert: (rows: any) => { op = "upsert"; ins = Array.isArray(rows) ? rows : [rows]; return q; },
      update: (p: any) => { op = "update"; patch = p; return q; },
      delete: () => { op = "delete"; return q; },
      maybeSingle: () => run().then((r: any) => ({ ...r, data: Array.isArray(r.data) ? r.data[0] || null : r.data })),
      single: () => q.maybeSingle(),
      then: (ok: any, bad: any) => run().then(ok, bad),
    };
    const run = async () => {
      if (op === "insert" || op === "upsert") {
        for (const r of ins) { const e = badCol(table, r); if (e) return { data: null, error: e }; }
        const out = ins.map((r) => ({ id: r.id ?? crypto.randomUUID(), ...r }));
        t[table].push(...out); out.forEach((row) => log.push({ table, op, row }));
        return { data: out, error: null };
      }
      if (op === "update") {
        const e = badCol(table, patch); if (e) return { data: null, error: e };
        const rows = match(); rows.forEach((r) => Object.assign(r, patch)); log.push({ table, op, patch });
        return { data: rows, error: null };
      }
      if (op === "delete") { const rows = match(); t[table] = t[table].filter((r) => !rows.includes(r)); return { data: rows, error: null }; }
      let rows = match();
      if (order) { const { c, asc } = order; rows = [...rows].sort((a, b) => (a[c] > b[c] ? 1 : a[c] < b[c] ? -1 : 0) * (asc ? 1 : -1)); }
      const count = rows.length;
      rows = rows.slice(0, lim);
      return { data: head ? null : rows, error: null, count: countOn ? count : null };
    };
    return q;
  };
  const client: any = { from, rpc: async (fn: string, args: any) => (client.rpcImpl ? client.rpcImpl(fn, args) : { data: null, error: null }), storage: { from: () => ({}) } };
  return { t, log, client };
}

// ───────────────────────── app + helpers ─────────────────────────
const SECRET = "test_secret_v366";
function app(db: any, user: any, testMode = false) {
  const a = express(); a.use(express.json());
  const router = express.Router();
  setupPaymentRoutes(a, router, {
    supabase: db.client, privilegedSupabase: db.client, getDb: () => ({ transactions: [], chat_threads: [], deals: [] }), saveDb: () => {},
    parseAuthUser: async () => user, logAdminAction: async () => ({}), sendNotification: async () => ({}), fetchUserScopedTransactions: async () => [],
    serializeChatMessage: (m: any) => m, insertChatMessageToSupabase: async () => ({}), parseThreadState: () => ({}), getIsTestMode: () => testMode,
  } as any);
  a.use("/api", router);
  return a;
}
async function call(a: any, method: string, path: string, body?: any) {
  const srv = a.listen(0); const port = srv.address().port;
  try {
    const r = await fetch(`http://127.0.0.1:${port}/api${path}`, { method, headers: { "content-type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
    let j: any = null; try { j = await r.json(); } catch { j = null; }
    return { status: r.status, body: j };
  } finally { srv.close(); }
}
const sign = (o: string, p: string) => crypto.createHmac("sha256", SECRET).update(`${o}|${p}`).digest("hex");
const pay = (orderId: string, rupees?: number) => { const o = rz.orders.get(orderId)!; o.status = "paid"; o.amount_paid = rupees != null ? Math.round(rupees * 100) : o.amount; };

const DEAL = "11111111-1111-4111-8111-111111111111";
const SPLIT = { id: 1, fee_model: "split", creator_fee_pct: 0, brand_fee_pct: 8, threshold_amount: 20000, below_threshold_rate: 10, above_threshold_rate: 5, gst_rate: 18, platform_gst_registered: false, offer_mode: false, updated_at: "2026-10-21T00:00:00Z" };
const brand = { user_id: "b1", role: "brand", name: "Brand" };
const seed = (cfg: any = SPLIT, amount = 10000, extra: Record<string, any[]> = {}) => ({
  platform_fee_config: [cfg],
  coupons: [], coupon_redemptions: [], transactions: [],
  deals: [{ id: DEAL, agreed_amount: amount, creator_id: "c1", brand_id: "b1", status: "accepted" }],
  chat_threads: [{ id: `thread_camp_${DEAL}`, deal_id: DEAL, creator_id: "c1", brand_id: "b1", agreement_signed_creator: true, agreement_signed_brand: true }],
  ugc_orders: [], users: [{ user_id: "b1", role: "brand", email: "b@x.in" }, { user_id: "c1", role: "creator", email: "c@x.in" }],
  ...extra,
});

// ───────────────────────── shared bits ─────────────────────────
const coupon = (over: any = {}) => ({ id: "cp1", code: "DIWALI4", applies_to: "brand_fee", type: "fee_rate_override", override_fee_rate: 4, discount_amount: 0, status: "active", usage_limit: 0, used_count: 0, per_user_limit: 0, min_campaign_value: 0, valid_from: null, valid_until: null, ...over });
const tx = (db: any) => db.t.transactions.filter((r: any) => r.payout_type !== "refund");
const admin = { user_id: "adm", role: "admin" };
const reset = () => { rz.reset(); __resetFeeConfigCache(); process.env.RAZORPAY_KEY_SECRET = SECRET; process.env.RAZORPAY_KEY_ID = "rzp_test_x"; process.env.PAYMENTS_TEST_MODE = "false"; };
async function verify(a: any, orderId: string, body: any) {
  const pid = `pay_${orderId}`;
  return call(a, "POST", "/payments/razorpay/verify", { razorpay_order_id: orderId, razorpay_payment_id: pid, razorpay_signature: sign(orderId, pid), ...body });
}

// The database functions of migration v366_coupon_reservations (scripts/sql/v366_coupon_reservations.sql), modelled
// one-to-one. Each call runs to the end before the next (JS is single-threaded) — the same as the row lock
// (SELECT … FOR UPDATE) the real function takes on the coupon.
function couponRpc(db: any) {
  db.t.coupon_reservations = db.t.coupon_reservations || [];
  const R = () => db.t.coupon_reservations as any[];
  db.client.rpcImpl = async (fn: string, a: any) => {
    const now = Date.now();
    if (fn === "claim_coupon") {
      const c = db.t.coupons.find((x: any) => x.id === a.p_coupon_id);
      if (!c) return { data: { ok: false, reason: "not_found" }, error: null };
      const mine = R().find((r) => r.order_id === a.p_order_id);
      if (mine) return { data: { ok: true, existing: true }, error: null };
      if (c.status !== "active") return { data: { ok: false, reason: "inactive" }, error: null };
      const live = R().filter((r) => r.coupon_id === c.id && r.status === "reserved" && r.expires_at > now);
      if (Number(c.usage_limit) > 0 && Number(c.used_count) + live.length >= Number(c.usage_limit)) return { data: { ok: false, reason: "used_up" }, error: null };
      if (Number(c.per_user_limit) > 0) {
        const byBrand = R().filter((r) => r.coupon_id === c.id && r.brand_id === a.p_brand_id && (r.status === "confirmed" || (r.status === "reserved" && r.expires_at > now))).length;
        const legacy = R().some((r) => r.coupon_id === c.id && r.brand_id === a.p_brand_id && r.status === "confirmed") ? 0 : db.t.coupon_redemptions.filter((x: any) => x.coupon_id === c.id && x.user_id === a.p_brand_id).length;
        if (byBrand + legacy >= Number(c.per_user_limit)) return { data: { ok: false, reason: "brand_limit" }, error: null };
      }
      R().push({ id: crypto.randomUUID(), coupon_id: c.id, brand_id: a.p_brand_id, order_id: a.p_order_id, status: "reserved", discount: a.p_discount, expires_at: now + a.p_ttl_minutes * 60000 });
      return { data: { ok: true }, error: null };
    }
    if (fn === "confirm_coupon") {
      const r = R().find((x) => x.order_id === a.p_order_id);
      if (!r) return { data: { ok: false, reason: "no_reservation" }, error: null };
      if (r.status === "confirmed") return { data: { ok: true, already: true }, error: null };
      r.status = "confirmed";
      const c = db.t.coupons.find((x: any) => x.id === r.coupon_id); c.used_count = Number(c.used_count) + 1;
      if (!db.t.coupon_redemptions.some((x: any) => x.coupon_id === c.id && x.user_id === a.p_brand_id)) db.t.coupon_redemptions.push({ id: crypto.randomUUID(), coupon_id: c.id, user_id: a.p_brand_id, deal_id: a.p_deal_id, ugc_order_id: a.p_ugc_order_id, campaign_id: a.p_campaign_id, discount_applied: a.p_discount });
      return { data: { ok: true }, error: null };
    }
    return { data: null, error: { code: "PGRST202", message: `Could not find the function public.${fn}` } };
  };
  return db;
}

// ───────────────────────── 1. instant UGC: amount from the server ─────────────────────────
const UGC = (over: any = {}) => ({ id: "ugcord_A", brand_id: "b1", creator_id: "c1", creator_payout: 5000, escrow_amount: null, agreed_amount: 5000, escrow_hold: false, payment_status: "pending", status: "active", ...over });
describe("v366 · instant UGC order: the server decides the amount", () => {
  beforeEach(reset);
  it("browser sends ₹1 → the order is ₹5,000 + 8% = ₹5,400, bound to the UGC order", async () => {
    const db = fakeDb(seed(SPLIT, 10000, { ugc_orders: [UGC()] }));
    const r = await call(app(db, brand), "POST", "/payments/razorpay/create-order", { deal_id: "ugcord_A", gross_amount: 1 });
    expect(r.status).toBe(200);
    expect(r.body.amount).toBe(540000);
    expect(rz.orders.get(r.body.order_id)!.notes).toMatchObject({ ugc_order_id: "ugcord_A", kind: "ugc_order", gross: "5000", brand_total: "5400" });
    // the chat thread id works the same way
    const t = await call(app(db, brand), "POST", "/payments/razorpay/create-order", { thread_id: "thread_ugc_ugcord_A", gross_amount: 1 });
    expect(t.body.amount).toBe(540000);
  });
  it("another brand's order → 403; an already-paid order → 409; no Razorpay order made", async () => {
    const db = fakeDb(seed(SPLIT, 10000, { ugc_orders: [UGC(), UGC({ id: "ugcord_P", escrow_hold: true, payment_status: "ESCROW_HELD" })] }));
    const other = await call(app(db, { user_id: "b2", role: "brand" }), "POST", "/payments/razorpay/create-order", { deal_id: "ugcord_A", gross_amount: 5000 });
    expect(other.status).toBe(403);
    expect(other.body.code).toBe("NOT_YOUR_ORDER");
    const paid = await call(app(db, brand), "POST", "/payments/razorpay/create-order", { deal_id: "ugcord_P", gross_amount: 5000 });
    expect(paid.status).toBe(409);
    expect(paid.body.code).toBe("ALREADY_PAID");
    expect(rz.orders.size).toBe(0);
  });
  it("a team member pays for the parent brand's order", async () => {
    const db = fakeDb(seed(SPLIT, 10000, { ugc_orders: [UGC()] }));
    const r = await call(app(db, { user_id: "tm1", role: "brand", parent_brand_id: "b1" }), "POST", "/payments/razorpay/create-order", { deal_id: "ugcord_A", gross_amount: 1 });
    expect(r.status).toBe(200);
    expect(r.body.amount).toBe(540000);
  });
  it("underpaying (₹5,000 of ₹5,400) is refused at verify — nothing recorded", async () => {
    const db = fakeDb(seed(SPLIT, 10000, { ugc_orders: [UGC()] }));
    const a = app(db, brand);
    const r = await call(a, "POST", "/payments/razorpay/create-order", { deal_id: "ugcord_A", gross_amount: 1 });
    pay(r.body.order_id, 5000);
    const v = await verify(a, r.body.order_id, { deal_id: "ugcord_A" });
    expect(v.status).not.toBe(200);
    expect(tx(db)).toHaveLength(0);
  });
  it("a paid order can't be used for a different UGC order", async () => {
    const db = fakeDb(seed(SPLIT, 10000, { ugc_orders: [UGC(), UGC({ id: "ugcord_B", creator_payout: 100, agreed_amount: 100 })] }));
    const a = app(db, brand);
    const r = await call(a, "POST", "/payments/razorpay/create-order", { deal_id: "ugcord_A", gross_amount: 1 });
    pay(r.body.order_id);
    const v = await verify(a, r.body.order_id, { deal_id: "ugcord_B" });
    expect(v.status).not.toBe(200);
    expect(tx(db).filter((x: any) => x.ugc_order_id === "ugcord_B")).toHaveLength(0);
  });
  it("paid in full → recorded at ₹5,000 for the creator, ₹5,400 from the brand", async () => {
    const db = fakeDb(seed(SPLIT, 10000, { ugc_orders: [UGC()] }));
    const a = app(db, brand);
    const r = await call(a, "POST", "/payments/razorpay/create-order", { deal_id: "ugcord_A", gross_amount: 1 });
    pay(r.body.order_id);
    const v = await verify(a, r.body.order_id, { deal_id: "ugcord_A" });
    expect(v.status).toBe(200);
    expect(tx(db)[0]).toMatchObject({ gross_amount: 5000, creator_net_amount: 5000, brand_fee_amount: 400, brand_paid_amount: 5400 });
  });
  it("an order made before v366 (no ugc_order_id on it) still verifies as before", async () => {
    const db = fakeDb(seed(SPLIT, 10000, { ugc_orders: [UGC()] }));
    const old = await rz.api.orders.create({ amount: 500000, currency: "INR", notes: {} });
    pay(old.id);
    const v = await verify(app(db, brand), old.id, { deal_id: "ugcord_A" });
    expect(v.status).toBe(200);
    expect(tx(db)[0]).toMatchObject({ gross_amount: 5000 });
  });
});

// ───────────────────────── 2. coupon: last use, two brands at once ─────────────────────────
describe("v366 · coupon race (atomic claim / confirm in the database)", () => {
  beforeEach(reset);
  const twoBrands = () => fakeDb(seed(SPLIT, 10000, {
    deals: [
      { id: DEAL, agreed_amount: 10000, creator_id: "c1", brand_id: "b1", status: "accepted" },
      { id: "22222222-2222-4222-8222-222222222222", agreed_amount: 10000, creator_id: "c1", brand_id: "b2", status: "accepted" },
    ],
    chat_threads: [
      { id: `thread_camp_${DEAL}`, deal_id: DEAL, creator_id: "c1", brand_id: "b1", agreement_signed_creator: true, agreement_signed_brand: true },
      { id: "thread_camp_22222222-2222-4222-8222-222222222222", deal_id: "22222222-2222-4222-8222-222222222222", creator_id: "c1", brand_id: "b2", agreement_signed_creator: true, agreement_signed_brand: true },
    ],
    coupons: [coupon({ usage_limit: 1 })],
  }));
  it("the last use: two brands check out at the same moment → exactly one gets it", async () => {
    const db = couponRpc(twoBrands());
    const [r1, r2] = await Promise.all([
      call(app(db, brand), "POST", "/payments/razorpay/create-order", { deal_id: DEAL, coupon_code: "DIWALI4" }),
      call(app(db, { user_id: "b2", role: "brand" }), "POST", "/payments/razorpay/create-order", { deal_id: "22222222-2222-4222-8222-222222222222", coupon_code: "DIWALI4" }),
    ]);
    const ok = [r1, r2].filter((r) => r.status === 200);
    const no = [r1, r2].filter((r) => r.status === 400);
    expect(ok).toHaveLength(1);
    expect(no).toHaveLength(1);
    expect(no[0].body.code).toBe("COUPON_INVALID");
    expect(db.t.coupon_reservations.filter((r: any) => r.status === "reserved")).toHaveLength(1);
    // the winner pays → counted once; verifying twice doesn't count it again
    const win = ok[0] === r1 ? { a: app(db, brand), deal: DEAL } : { a: app(db, { user_id: "b2", role: "brand" }), deal: "22222222-2222-4222-8222-222222222222" };
    pay(ok[0].body.order_id);
    expect((await verify(win.a, ok[0].body.order_id, { deal_id: win.deal })).status).toBe(200);
    expect((await verify(win.a, ok[0].body.order_id, { deal_id: win.deal })).status).toBe(200);
    expect(db.t.coupons[0].used_count).toBe(1);
    expect(db.t.coupon_redemptions).toHaveLength(1);
    expect(tx(db)[0]).toMatchObject({ coupon_code: "DIWALI4", brand_paid_amount: 10400 });
  });
  it("per-brand limit 1: the same brand can't hold it on two orders", async () => {
    const db = couponRpc(fakeDb(seed(SPLIT, 10000, { coupons: [coupon({ per_user_limit: 1 })] })));
    const a = app(db, brand);
    const first = await call(a, "POST", "/payments/razorpay/create-order", { deal_id: DEAL, coupon_code: "DIWALI4" });
    expect(first.status).toBe(200);
    // a different order for the same brand (the reused-pending path would hand back the same order, so clear it)
    const second = await claimBrandCoupon(db.client, { couponId: "cp1", brandId: "b1", orderId: "order_other" });
    expect(second).toMatchObject({ ok: false, reason: "You've already used this coupon." });
  });
  it("claim for the same order twice is fine (retries / reused orders)", async () => {
    const db = couponRpc(fakeDb(seed(SPLIT, 10000, { coupons: [coupon({ usage_limit: 1 })] })));
    expect(await claimBrandCoupon(db.client, { couponId: "cp1", brandId: "b1", orderId: "o1" })).toEqual({ ok: true });
    expect(await claimBrandCoupon(db.client, { couponId: "cp1", brandId: "b1", orderId: "o1" })).toEqual({ ok: true });
    expect((await claimBrandCoupon(db.client, { couponId: "cp1", brandId: "b2", orderId: "o2" })).ok).toBe(false);
  });
  it("database functions missing (migration not run) → the old way still works: checkout + count once", async () => {
    const db = fakeDb(seed(SPLIT, 10000, { coupons: [coupon()] }));
    db.client.rpcImpl = async (fn: string) => ({ data: null, error: { code: "PGRST202", message: `Could not find the function public.${fn}(…) in the schema cache` } });
    const a = app(db, brand);
    const r = await call(a, "POST", "/payments/razorpay/create-order", { deal_id: DEAL, coupon_code: "DIWALI4" });
    expect(r.status).toBe(200);
    expect(r.body.amount).toBe(1040000);
    pay(r.body.order_id);
    expect((await verify(a, r.body.order_id, { deal_id: DEAL })).status).toBe(200);
    expect(db.t.coupon_redemptions).toHaveLength(1);
    expect(db.t.coupons[0].used_count).toBe(1);
    expect(await confirmBrandCoupon(db.client, { orderId: "x", couponId: "cp1", brandId: "b9" })).toEqual({ ok: true, via: "legacy" });
  });
  it("database error while claiming (not 'missing') → calm COUPON_INVALID, no money taken", async () => {
    const db = fakeDb(seed(SPLIT, 10000, { coupons: [coupon()] }));
    db.client.rpcImpl = async () => ({ data: null, error: { code: "57014", message: "canceling statement due to statement timeout" } });
    const r = await call(app(db, brand), "POST", "/payments/razorpay/create-order", { deal_id: DEAL, coupon_code: "DIWALI4" });
    expect(r.status).toBe(400);
    expect(r.body.detail).toMatch(/can't be checked right now/);
  });
  it("only service_role may run the functions (grants in the SQL file)", () => {
    const sql = read("scripts/sql/v366_coupon_reservations.sql");
    for (const fn of ["claim_coupon", "confirm_coupon", "release_coupon"]) {
      expect(sql).toMatch(new RegExp(`revoke\\s+all\\s+on\\s+function\\s+public\\.${fn}[^;]*from\\s+public,\\s*anon,\\s*authenticated`, "i"));
      expect(sql).toMatch(new RegExp(`grant\\s+execute\\s+on\\s+function\\s+public\\.${fn}[^;]*to\\s+service_role`, "i"));
    }
    expect(sql).toMatch(/for update/i);
  });
});

// ───────────────────────── 3. refunds: fee first, then the deal ─────────────────────────
import { refundBlock, refundableLeft, feeRefundedSoFar, refundNote, netAfterPartialRefund, isServiceFeeRefund } from "./adminMoney";
describe("v366 · more refunds after a fee-only refund (never more than paid)", () => {
  beforeEach(reset);
  async function paid(db: any) {
    const a = app(db, brand);
    const r = await call(a, "POST", "/payments/razorpay/create-order", { deal_id: DEAL });
    pay(r.body.order_id);
    await verify(a, r.body.order_id, { deal_id: DEAL });
    return tx(db)[0];
  }
  it("₹800 fee refund, then ₹10,000 deal refund → total ₹10,800, creator ₹0; nothing more allowed", async () => {
    const db = fakeDb(seed());
    const t = await paid(db);
    const A = app(db, admin);
    expect((await call(A, "POST", `/admin/transactions/${t.id}/refund`, { refund_amount: 800, refund_from: "fee", refund_reason: "goodwill", refund_status: "PROCESSED", refund_reference: "UTR111111" })).status).toBe(200);
    const row = () => tx(db)[0];
    expect(row()).toMatchObject({ refund_amount: 800, refund_status: "PROCESSED", status: "SUCCESS" });
    expect(isServiceFeeRefund(row())).toBe(true); // v365 tag kept
    expect(refundableLeft(row())).toBe(10000);
    // too much: ₹10,001 left would be more than paid
    const over = await call(A, "POST", `/admin/transactions/${t.id}/refund`, { refund_amount: 10001, refund_from: "deal", refund_status: "PROCESSED", refund_reference: "UTR222222" });
    expect(over.status).toBe(400);
    expect(over.body.error).toBe("Already refunded ₹800 · only ₹10,000 can still be refunded.");
    const deal = await call(A, "POST", `/admin/transactions/${t.id}/refund`, { refund_amount: 10000, refund_from: "deal", refund_reason: "creator never delivered", refund_status: "PROCESSED", refund_reference: "UTR333333" });
    expect(deal.status).toBe(200);
    expect(row()).toMatchObject({ refund_amount: 10800, refund_status: "PROCESSED", status: "REFUNDED" });
    expect(feeRefundedSoFar(row())).toBe(800);
    expect(String(row().refund_reference)).toContain("UTR111111");
    expect(String(row().refund_reference)).toContain("UTR333333");
    expect(netAfterPartialRefund(row(), 10000)).toBe(0);
    const more = await call(A, "POST", `/admin/transactions/${t.id}/refund`, { refund_amount: 1, refund_status: "PROCESSED", refund_reference: "UTR444444" });
    expect(more.status).toBe(409);
  });
  it("part deal refund ₹2,000 then fee ₹800: creator loses only ₹2,000", async () => {
    const db = fakeDb(seed());
    const t = await paid(db);
    const A = app(db, admin);
    await call(A, "POST", `/admin/transactions/${t.id}/refund`, { refund_amount: 2000, refund_from: "deal", refund_status: "PROCESSED", refund_reference: "UTR555555" });
    const f = await call(A, "POST", `/admin/transactions/${t.id}/refund`, { refund_amount: 800, refund_from: "fee", refund_status: "PROCESSED", refund_reference: "UTR666666" });
    expect(f.status).toBe(200);
    const row = tx(db)[0];
    expect(row).toMatchObject({ refund_amount: 2800, status: "SUCCESS" });
    expect(feeRefundedSoFar(row)).toBe(800);
    expect(netAfterPartialRefund(row, 10000)).toBe(8000);
    // fee is used up now
    expect(refundBlock(row, 1, "PROCESSED", "fee")?.status).toBe(400);
  });
  it("completing a PENDING refund keeps its amount as the total (not added twice)", async () => {
    const db = fakeDb(seed());
    const t = await paid(db);
    const A = app(db, admin);
    await call(A, "POST", `/admin/transactions/${t.id}/refund`, { refund_amount: 500, refund_from: "deal", refund_status: "PENDING" });
    const done = await call(A, "POST", `/admin/transactions/${t.id}/refund`, { refund_amount: 500, refund_from: "deal", refund_status: "PROCESSED", refund_reference: "UTR777777" });
    expect(done.status).toBe(200);
    expect(tx(db)[0]).toMatchObject({ refund_amount: 500, refund_status: "PROCESSED" });
  });
  it("note rules: running fee total in the tag; v365 tag-only notes count all as fee", () => {
    const base = { refund_status: "PROCESSED", brand_paid_amount: 10800, gross_amount: 10000, brand_fee_amount: 800 };
    expect(refundNote({ ...base, refund_amount: 0 }, "fee", 300, "Diwali")).toBe("[service-fee refund] fee ₹300 · Diwali");
    const after = { ...base, refund_amount: 300, fee_correction_note: "[service-fee refund] fee ₹300 · Diwali" };
    expect(feeRefundedSoFar(after)).toBe(300);
    expect(refundNote(after, "fee", 200, after.fee_correction_note)).toBe("[service-fee refund] fee ₹500 · Diwali");
    expect(refundNote(after, "deal", 1000, "late")).toBe("[service-fee refund] fee ₹300 · late · Diwali");
    expect(feeRefundedSoFar({ ...base, refund_amount: 800, fee_correction_note: "[service-fee refund] Diwali goodwill" })).toBe(800);
    expect(refundNote({ ...base, refund_amount: 0 }, "deal", 100, "x")).toBe("x");
  });
});

// ───────────────────────── 4. test-mode payments are stamped like real ones ─────────────────────────
describe("v366 · test-mode order_test_ payments", () => {
  beforeEach(reset);
  it("brand fee stamped, coupon counted once", async () => {
    const db = couponRpc(fakeDb(seed(SPLIT, 10000, { coupons: [coupon()] })));
    rz.flags.failCreate = true; // Razorpay unavailable → simulated order in test mode
    const a = app(db, brand, true);
    const r = await call(a, "POST", "/payments/razorpay/create-order", { deal_id: DEAL, coupon_code: "DIWALI4" });
    expect(r.status).toBe(200);
    expect(String(r.body.order_id)).toMatch(/^order_test_/);
    expect(r.body.amount).toBe(1040000);
    const pid = `pay_test_${Date.now()}`;
    const v = await call(a, "POST", "/payments/razorpay/verify", { razorpay_order_id: r.body.order_id, razorpay_payment_id: pid, razorpay_signature: "test", deal_id: DEAL });
    expect(v.status).toBe(200);
    expect(tx(db)[0]).toMatchObject({ gross_amount: 10000, creator_net_amount: 10000, brand_fee_pct: 4, brand_fee_amount: 400, brand_paid_amount: 10400, coupon_code: "DIWALI4" });
    expect(db.t.coupons[0].used_count).toBe(1);
    expect(db.t.coupon_redemptions).toHaveLength(1);
  });
});

// ───────────────────────── 5 + 6. UGC: refunds queue fee view, team-member deposit ─────────────────────────
import { setupUgcBrowseRoutes } from "./ugc_routes";
import { feeView, feeRefundProblem, attachFeeViews, isUgcFeeRefund } from "./ugcFeeRefunds";
const ugcApp = (db: any, user: any, local: any = { ugc_briefs: [], transactions: [], ugc_orders: [], ugc_refunds: [], users: [], brand_profiles: [] }) => {
  const a = express(); a.use(express.json());
  const router = express.Router();
  setupPaymentRoutes(a, router, {
    supabase: db.client, privilegedSupabase: db.client, getDb: () => ({ transactions: [], chat_threads: [], deals: [] }), saveDb: () => {},
    parseAuthUser: async () => user, logAdminAction: async () => ({}), sendNotification: async () => ({}), fetchUserScopedTransactions: async () => [],
    serializeChatMessage: (m: any) => m, insertChatMessageToSupabase: async () => ({}), parseThreadState: () => ({}), getIsTestMode: () => false,
  } as any);
  setupUgcBrowseRoutes(a, router, { supabase: db.client, privilegedSupabase: db.client, getDb: () => local, saveDb: () => {}, parseAuthUser: async () => user, ensureUGCChatThread: async () => ({}), enrichBriefsWithBrandProfiles: async (b: any[]) => b } as any);
  a.use("/api", router);
  return a;
};
const DEPOSIT = { id: "dep1", brief_id: "brief1", brand_id: "b1", deal_id: null, ugc_order_id: null, gross_amount: 6000, brand_paid_amount: 6240, brand_fee_amount: 240, brand_fee_gst: 0, brand_fee_pct: 4, coupon_code: "DIWALI4" };
const ACC = { brand_id: "b1", method_type: "UPI", upi_id: "brand@upi" };
const CANCEL = { id: "ugcref_1", brief_id: "brief1", brand_id: "b1", amount: 2000, slots: 1, reason: "Brand cancelled unused brief slots", status: "PENDING", refund_account_snapshot: { method_type: "UPI", upi_id: "brand@upi" }, requested_at: "2026-10-20T10:00:00Z" };

describe("v366 · Admin → UGC Refunds shows the fee and can refund it", () => {
  beforeEach(reset);
  it("queue rows carry brand paid / service fee / coupon from the brief's deposit", async () => {
    const db = fakeDb(seed(SPLIT, 10000, { transactions: [DEPOSIT], ugc_refunds: [CANCEL], brand_refund_accounts: [ACC] }));
    const r = await call(ugcApp(db, admin), "GET", "/admin/ugc-refunds");
    expect(r.status).toBe(200);
    expect(r.body[0].fee_view).toEqual({ brand_paid: 6240, deal_amount: 6000, service_fee: 240, fee_pct: 4, coupon_code: "DIWALI4", fee_refunded: 0, total_refunded: 2000, fee_left: 240, total_left: 4240 });
    expect(r.body[0].is_fee_refund).toBe(false);
  });
  it("manual fee refund: capped at the fee, needs a reason, admin only; lands as PENDING (slots 0) in the queue", async () => {
    const db = fakeDb(seed(SPLIT, 10000, { transactions: [DEPOSIT], ugc_refunds: [CANCEL], brand_refund_accounts: [ACC] }));
    const A = ugcApp(db, admin);
    expect((await call(ugcApp(db, brand), "POST", "/admin/ugc-refunds/fee", { brief_id: "brief1", amount: 100, reason: "goodwill" })).status).toBe(403);
    const over = await call(A, "POST", "/admin/ugc-refunds/fee", { brief_id: "brief1", amount: 241, reason: "goodwill" });
    expect(over.status).toBe(400);
    expect(over.body.error).toBe("Only ₹240 of the service fee can still be refunded.");
    expect((await call(A, "POST", "/admin/ugc-refunds/fee", { brief_id: "brief1", amount: 100, reason: "" })).status).toBe(400);
    const ok = await call(A, "POST", "/admin/ugc-refunds/fee", { brief_id: "brief1", amount: 140, reason: "creator late" });
    expect(ok.status).toBe(200);
    const row = db.t.ugc_refunds.find((x: any) => x.id !== "ugcref_1");
    expect(row).toMatchObject({ brief_id: "brief1", brand_id: "b1", amount: 140, slots: 0, status: "PENDING", reason: "[service-fee refund] creator late", refund_account_snapshot: expect.objectContaining({ upi_id: "brand@upi" }) });
    expect(isUgcFeeRefund(row)).toBe(true);
    expect(ok.body.fee_view.fee_left).toBe(100);
    expect((await call(A, "POST", "/admin/ugc-refunds/fee", { brief_id: "brief1", amount: 101, reason: "again" })).status).toBe(400);
    expect((await call(A, "POST", "/admin/ugc-refunds/fee", { brief_id: "brief1", amount: 100, reason: "rest of it" })).status).toBe(200);
    const none = await call(A, "POST", "/admin/ugc-refunds/fee", { brief_id: "brief1", amount: 1, reason: "more" });
    expect(none.body.error).toBe("The service fee has already been refunded.");
    // it then goes through the normal "mark as sent with UTR" step
    const p = await call(A, "POST", `/admin/ugc-refunds/${row.id}/process`, { utr: "UTR998877" });
    expect(p.status).toBe(200);
    expect(db.t.ugc_refunds.find((x: any) => x.id === row.id).status).toBe("PROCESSED");
  });
  it("no refund account / no fee → refused", async () => {
    const db = fakeDb(seed(SPLIT, 10000, { transactions: [DEPOSIT], ugc_refunds: [], brand_refund_accounts: [] }));
    expect((await call(ugcApp(db, admin), "POST", "/admin/ugc-refunds/fee", { brief_id: "brief1", amount: 10, reason: "goodwill" })).body.code).toBe("REFUND_ACCOUNT_REQUIRED");
    const old = fakeDb(seed(SPLIT, 10000, { transactions: [{ ...DEPOSIT, brand_fee_amount: null, brand_paid_amount: null, coupon_code: null }], brand_refund_accounts: [ACC] }));
    expect((await call(ugcApp(old, admin), "POST", "/admin/ugc-refunds/fee", { brief_id: "brief1", amount: 10, reason: "goodwill" })).body.error).toBe("This brief has no service fee to refund.");
  });
  it("caps never let the total pass what the brand paid; failed refunds don't count", () => {
    const v = feeView(DEPOSIT, [{ amount: 6100, status: "PROCESSED", reason: "slots" }, { amount: 240, status: "FAILED", reason: "[service-fee refund] x" }])!;
    expect(v).toMatchObject({ total_refunded: 6100, fee_refunded: 0, fee_left: 140, total_left: 140 });
    expect(feeRefundProblem(v, 141, "goodwill")).toMatch(/Only ₹140/);
    expect(feeRefundProblem(v, 140, "goodwill")).toBeNull();
  });
  it("the queue still loads if the deposit lookup fails", async () => {
    const broken = { from: () => ({ select: () => ({ in: async () => { throw new Error("down"); } }) }) };
    const out = await attachFeeViews(broken, [CANCEL]);
    expect(out[0]).toMatchObject({ id: "ugcref_1", fee_view: null });
  });
});

describe("v366 · UGC brief deposit by a team member belongs to the brand", () => {
  beforeEach(reset);
  it("deposit row brand_id = parent brand (b1), not the member (tm1)", async () => {
    const db = fakeDb(seed()); db.t.ugc_briefs = [];
    const member = { user_id: "tm1", role: "brand", parent_brand_id: "b1", name: "Member" };
    const a = ugcApp(db, member);
    const order = await call(a, "POST", "/payments/razorpay/create-order", { gross_amount: 6000 });
    expect(order.body.amount).toBe(648000);
    pay(order.body.order_id);
    const brief = await call(a, "POST", "/ugc/briefs", { title: "T", product_name: "P", budget: 2000, max_creators: 3, razorpay_order_id: order.body.order_id, deliverable_type: "ugc_video" });
    expect(brief.status).toBe(200);
    const dep = db.t.transactions.find((r: any) => r.brief_id);
    expect(dep).toMatchObject({ brand_id: "b1", gross_amount: 6000, brand_paid_amount: 6480 });
  });
  it("an owner's deposit is unchanged (brand_id = own id)", async () => {
    const db = fakeDb(seed()); db.t.ugc_briefs = [];
    const a = ugcApp(db, brand);
    const order = await call(a, "POST", "/payments/razorpay/create-order", { gross_amount: 6000 });
    pay(order.body.order_id);
    await call(a, "POST", "/ugc/briefs", { title: "T", product_name: "P", budget: 2000, max_creators: 3, razorpay_order_id: order.body.order_id, deliverable_type: "ugc_video" });
    expect(db.t.transactions.find((r: any) => r.brief_id).brand_id).toBe("b1");
  });
});

// ───────────────────────── 7. coupon form: empty per-brand limit = no limit ─────────────────────────
import { setupAdminVersionsCouponsRoutes, perUserLimitInput } from "./admin_versions_coupons_routes";
import { brandCouponProblem } from "./brandFee";
describe("v366 · coupon per-brand limit: empty means no limit", () => {
  beforeEach(reset);
  const adminApp = (db: any) => {
    const a = express(); a.use(express.json());
    const router = express.Router();
    setupAdminVersionsCouponsRoutes(a, router, { supabase: db.client, privilegedSupabase: db.client, getDb: () => ({ coupons: [] }), saveDb: () => {}, parseAuthUser: async () => admin, logAdminAction: async () => ({}), sendNotification: async () => ({}) } as any);
    a.use("/api", router);
    return a;
  };
  it("'' / null / 0 / junk → 0 (no limit); 3 → 3", () => {
    expect(["", null, undefined, 0, -2, "abc"].map(perUserLimitInput)).toEqual([0, 0, 0, 0, 0, 0]);
    expect(perUserLimitInput("3")).toBe(3);
  });
  it("saving the form with the box empty stores 0, and the brand can use it again and again", async () => {
    const db = fakeDb(seed());
    const r = await call(adminApp(db), "POST", "/admin/coupons", { code: "nolimit", applies_to: "brand_fee", type: "fee_rate_override", override_fee_rate: 4, usage_limit: 0, per_user_limit: "", status: "active" });
    expect([200, 201]).toContain(r.status);
    expect(db.t.coupons[0].per_user_limit).toBe(0);
    expect(brandCouponProblem(db.t.coupons[0], { gross: 10000, usedByThisBrand: 5 })).toBe("");
    const listed = await call(adminApp(db), "GET", "/admin/coupons");
    const rows = Array.isArray(listed.body) ? listed.body : listed.body.coupons;
    expect(rows.find((c: any) => c.code === "NOLIMIT").per_user_limit).toBe(0); // was shown as 1, so a re-save quietly added a limit
  });
  it("the form starts empty with the hint", () => {
    const src = read("src/components/admin/PlatformTools.jsx");
    expect(src).toContain("Leave empty for no limit");
    expect(src).toContain('placeholder="No limit"');
    expect(src).not.toMatch(/^\s*per_user_limit: 1,$/m);
  });
});
