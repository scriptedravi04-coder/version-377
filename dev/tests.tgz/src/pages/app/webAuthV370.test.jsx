// v370 (Ravi: "website pe bhi app wala login"): /login and /signup open the app sign-in; links keep role / next / utm.
import React from "react";
import { describe, it, expect, vi, afterEach, beforeEach } from "vitest";
import { render, screen, fireEvent, cleanup, waitFor, act } from "@testing-library/react";
import { MemoryRouter, Routes, Route, useLocation } from "react-router-dom";
import { readFileSync } from "fs";
import { appAuthTarget } from "../../lib/standalone";

const net = vi.hoisted(() => ({ post: vi.fn(), get: vi.fn() }));
vi.mock("../../lib/api", () => ({ api: { post: net.post, get: net.get } }));
const auth = vi.hoisted(() => ({ login: vi.fn(), signup: vi.fn(), setUser: vi.fn() }));
vi.mock("../../contexts/AuthContext", () => ({ useAuth: () => ({ user: null, loading: false, ...auth }) }));
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn() }) }));
import AppContinue from "./AppContinue";

function Where() { const l = useLocation(); return <div data-testid="where">{l.pathname + l.search}</div>; }
afterEach(() => { cleanup(); vi.clearAllMocks(); });

describe("v370 · where /login and /signup go", () => {
  it("role from the link skips the role cards; the rest of the link stays", () => {
    expect(appAuthTarget("?role=creator&utm_source=meta&utm_campaign=c1")).toBe("/app/continue/creator?utm_source=meta&utm_campaign=c1");
    expect(appAuthTarget("?role=brand")).toBe("/app/continue/brand");
    expect(appAuthTarget("?role=agency&ref=AB12")).toBe("/app/continue/brand?ref=AB12");
    expect(appAuthTarget("")).toBe("/app");
    expect(appAuthTarget("?next=%2Fchallenge")).toBe("/app?next=%2Fchallenge");
    expect(appAuthTarget("?demo=1")).toBeNull(); // test-server demo login keeps the old form
  });
  it("App.jsx wires it; the role cards keep the link's query", () => {
    const app = readFileSync("src/App.jsx", "utf8");
    expect(app).toContain('path="/signup" element={<WebAuthToApp>');
    expect(app).toContain('<PhoneFrame><AppContinue /></PhoneFrame>');
    expect(readFileSync("src/components/app/AppLoginScreen.jsx", "utf8")).toContain("to={to + keepQuery()}");
  });
});

describe("v370 · app sign-in on the website", () => {
  const open = (url) => {
    window.history.replaceState(null, "", url);
    return render(
      <MemoryRouter initialEntries={[url]}>
        <Routes><Route path="/app/continue/:role" element={<AppContinue />} /><Route path="*" element={<Where />} /></Routes>
      </MemoryRouter>);
  };
  beforeEach(() => { try { window.sessionStorage.clear(); } catch { /* */ } });

  it("existing creator with a password → password box, OTP as the second option; login returns to ?next", async () => {
    net.post.mockResolvedValueOnce({ data: { exists: true, role: "creator", has_password: true } });
    auth.login.mockResolvedValueOnce({ user_id: "c1", role: "creator", onboarded: true });
    open("/app/continue/creator?next=%2Fchallenge&email=ravi%40x.com"); // ?email= opens the login view directly
    expect(screen.getByTestId("app-email").value).toBe("ravi@x.com");
    fireEvent.click(screen.getByTestId("app-email-continue"));
    await screen.findByText("Log in with OTP instead");
    const pw = document.querySelector('input[type="password"]');
    fireEvent.change(pw, { target: { value: "secret123" } });
    fireEvent.submit(pw.closest("form"));
    await waitFor(() => expect(screen.getByTestId("where").textContent).toBe("/challenge"));
  });
  it("brand link opened by a creator: one tap switches side, link kept", async () => {
    open("/app/continue/brand?utm_campaign=b1");
    expect(screen.getByTestId("app-switch-role").textContent).toMatch(/Continue as a Creator/);
    fireEvent.click(screen.getByTestId("app-switch-role"));
    await act(async () => {});
    expect(screen.getByTestId("app-role-line").textContent).toMatch(/a Creator/);
    expect(screen.getByTestId("app-switch-role").textContent).toMatch(/Continue as a Brand/);
  });
  // v376 (Ravi: "signup ke time password hatao"): a new email gets the code straight away — no password box.
  it("new email → no password box, the account is made and the code is sent", async () => {
    net.post.mockResolvedValueOnce({ data: { exists: false } }).mockResolvedValueOnce({ data: { requiresVerification: true } });
    open("/app/continue/creator");
    fireEvent.click(screen.getByTestId("app-have-account")); // v376: creators see the one-screen join first; login is one tap away
    fireEvent.change(screen.getByTestId("app-email"), { target: { value: "new@x.com" } });
    fireEvent.click(screen.getByTestId("app-email-continue"));
    expect(await screen.findByTestId("app-verify-code")).toBeTruthy();
    expect(document.querySelector('input[type="password"]')).toBeNull();
    expect(net.post).toHaveBeenCalledWith("auth/signup", expect.objectContaining({ email: "new@x.com", passwordless: true }));
  });
  it("Google on the website remembers the side and where to return", async () => {
    net.get.mockResolvedValueOnce({ data: { url: "https://accounts.google.com/o/oauth2" } });
    const assign = vi.fn();
    const orig = window.location;
    delete window.location; window.location = { ...orig, href: "", search: "?next=%2Fchallenge", assign };
    try {
      open("/app/continue/brand?next=%2Fchallenge");
      fireEvent.click(screen.getByTestId("app-oauth-google"));
      await waitFor(() => expect(window.sessionStorage.getItem("ybex_oauth_role")).toBe("brand"));
      expect(window.sessionStorage.getItem("ybex_oauth_next")).toBe("/challenge");
    } finally { window.location = orig; }
  });
});

describe("v371 · Instagram / Facebook in-app browser", () => {
  it("hides Google (blocked there) and says how to open in a browser", () => {
    const ua = Object.getOwnPropertyDescriptor(window.navigator, "userAgent");
    Object.defineProperty(window.navigator, "userAgent", { value: "Mozilla/5.0 (iPhone) Instagram 300.0", configurable: true });
    try {
      render(<MemoryRouter initialEntries={["/app/continue/creator"]}><Routes><Route path="/app/continue/:role" element={<AppContinue />} /></Routes></MemoryRouter>);
      expect(screen.queryByTestId("app-oauth-google")).toBeNull();
      expect(screen.getByTestId("app-inapp-tip").textContent).toMatch(/Open in browser/);
    } finally { if (ua) Object.defineProperty(window.navigator, "userAgent", ua); else delete window.navigator.userAgent; }
  });
});
