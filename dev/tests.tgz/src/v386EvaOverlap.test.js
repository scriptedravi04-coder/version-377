import { describe, it, expect } from "vitest";
import fs from "fs";

// v386 (Ravi 30 Oct 2026): Eva on desktop floats over the page; the page behind keeps its full width.
describe("v386 · desktop Eva overlaps the page instead of shrinking it", () => {
  const src = fs.readFileSync("src/components/feedback/FeedbackBot.jsx", "utf8");
  it("no longer pads the scroll container when the panel opens", () => {
    expect(src).not.toMatch(/style\.paddingRight\s*=/);
    expect(src).not.toContain("552px");
  });
  it("the docked panel is still a fixed floating glass panel on the right", () => {
    expect(src).toContain('data-desktop={desktop ? (docked ? "docked" : "drawer") : undefined}');
    expect(src).toMatch(/right: docked \? 16 : 0/);
  });
});
