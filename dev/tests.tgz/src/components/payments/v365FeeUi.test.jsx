// v365 deep test (Ravi: "UI/UX, proper calls … sab sahi se working"). The money screens of the split fee, rendered with
// a stubbed api: what the brand sees before paying, what the receipt says, and what the admin refund desk sends.
import { describe, it, expect, vi, beforeEach } from "vitest";
import React from "react";
import { render, screen, cleanup, fireEvent, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
const apiMock = vi.hoisted(() => ({ get: vi.fn(), post: vi.fn(), put: vi.fn() }));
vi.mock("../../lib/api", () => ({ api: apiMock }));
vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn() } }));
import BrandFeeSummary from "./BrandFeeSummary";
import InvoiceModal from "./InvoiceModal";
import MobileEscrowSheet from "../chat/mobile/MobileEscrowSheet";
import RefundModal from "../admin/RefundModal";
import FeesSettingsCard from "../admin/platformTools/FeesSettingsCard";
import CouponList from "../admin/platformTools/CouponList";

// The shape POST /payments/quote returns (backend/brandFee.ts quoteBrandPayment) for a ₹10,000 deal.
const quote = (o = {}) => ({ feeModel: "split", gross: 10000, brandFeeBasePercent: 8, brandFeePercent: 8, brandFee: 800, brandFeeGst: 0, couponCode: null, couponDiscount: 0, total: 10800, creatorNet: 10000, creatorFeePercent: 0, ...o });
const txt = () => document.body.textContent.replace(/\s+/g, " ");

beforeEach(() => { cleanup(); apiMock.get.mockReset(); apiMock.post.mockReset(); apiMock.get.mockResolvedValue({ data: {} }); });

describe("v365 UI · Review & pay (BrandFeeSummary)", () => {
  it("shows deal ₹10,000 + service fee 8% ₹800 = ₹10,800 and the creator's 0% fee, from the SERVER quote", async () => {
    apiMock.post.mockResolvedValueOnce({ data: { quote: quote() } });
    render(<BrandFeeSummary dealId="d1" />);
    expect((await screen.findByTestId("fee-total")).textContent).toContain("₹10,800");
    expect(screen.getByTestId("fee-deal-amount").textContent).toContain("₹10,000");
    expect(screen.getByTestId("fee-service").textContent).toMatch(/Service fee 8%.*₹800/);
    expect(txt()).toContain("0% platform fee for creators");
    expect(apiMock.post).toHaveBeenCalledWith("payments/quote", expect.objectContaining({ deal_id: "d1", coupon_code: null }));
  });
  it("a coupon re-quotes and shows 'Coupon … applied: 4%' with the discount; the code is passed to onQuote", async () => {
    const onQuote = vi.fn();
    apiMock.post.mockResolvedValueOnce({ data: { quote: quote() } })
      .mockResolvedValueOnce({ data: { quote: quote({ couponCode: "DIWALI4", brandFeePercent: 4, brandFee: 400, couponDiscount: 400, total: 10400 }) } });
    render(<BrandFeeSummary dealId="d1" onQuote={onQuote} />);
    fireEvent.click(await screen.findByTestId("fee-coupon-open"));
    fireEvent.change(screen.getByTestId("fee-coupon-input"), { target: { value: "diwali4" } });
    fireEvent.click(screen.getByTestId("fee-coupon-apply"));
    expect((await screen.findByTestId("fee-coupon")).textContent).toMatch(/Coupon DIWALI4 applied: 4%.*−₹400/);
    expect(screen.getByTestId("fee-total").textContent).toContain("₹10,400");
    expect(apiMock.post).toHaveBeenLastCalledWith("payments/quote", expect.objectContaining({ coupon_code: "DIWALI4" }));
    expect(onQuote).toHaveBeenLastCalledWith(expect.objectContaining({ couponCode: "DIWALI4" }));
  });
  it("a refused coupon shows the server's reason and keeps the old total", async () => {
    apiMock.post.mockResolvedValueOnce({ data: { quote: quote() } })
      .mockResolvedValueOnce({ data: { quote: quote({ couponError: "This coupon has expired." }) } });
    render(<BrandFeeSummary dealId="d1" />);
    fireEvent.click(await screen.findByTestId("fee-coupon-open"));
    fireEvent.change(screen.getByTestId("fee-coupon-input"), { target: { value: "OLD" } });
    fireEvent.click(screen.getByTestId("fee-coupon-apply"));
    expect(await screen.findByText("This coupon has expired.")).toBeTruthy();
    expect(screen.getByTestId("fee-total").textContent).toContain("₹10,800");
  });
  it("UGC brief: label is the escrow, gross_amount is sent", async () => {
    apiMock.post.mockResolvedValueOnce({ data: { quote: quote({ gross: 6000, brandFee: 480, total: 6480, creatorNet: 6000 }) } });
    render(<BrandFeeSummary grossAmount={6000} />);
    expect((await screen.findByTestId("fee-total")).textContent).toContain("₹6,480");
    expect(screen.getByTestId("fee-deal-amount").textContent).toContain("Escrow");
    expect(apiMock.post).toHaveBeenCalledWith("payments/quote", expect.objectContaining({ gross_amount: 6000 }));
  });
  it("old tiered model: no service fee line, no coupon box", async () => {
    apiMock.post.mockResolvedValueOnce({ data: { quote: quote({ feeModel: "tiered", brandFeeBasePercent: 0, brandFee: 0, total: 10000 }) } });
    render(<BrandFeeSummary dealId="d1" />);
    await screen.findByTestId("fee-total");
    expect(screen.queryByTestId("fee-service")).toBeNull();
    expect(screen.queryByTestId("fee-coupon-open")).toBeNull();
  });
});

describe("v365 UI · mobile escrow sheet", () => {
  it("the big number and Pay button use the quoted total; onPay gets the coupon", async () => {
    apiMock.post.mockResolvedValueOnce({ data: { quote: quote() } })
      .mockResolvedValueOnce({ data: { quote: quote({ couponCode: "DIWALI4", brandFeePercent: 4, couponDiscount: 400, total: 10400 }) } });
    const onPay = vi.fn().mockResolvedValue(false);
    render(<MemoryRouter><MobileEscrowSheet amount={10000} isBrand isFunded={false} onPay={onPay} dealId="d1" onClose={() => {}} /></MemoryRouter>);
    // v366 requirement change (Ravi's checkout design): the button reads "Pay ₹X | via UPI" (was "Pay ₹X with UPI")
    await waitFor(() => expect(screen.getByTestId("escrow-pay").textContent).toMatch(/Pay ₹10,800\s*via UPI/));
    fireEvent.click(screen.getByTestId("fee-coupon-open"));
    fireEvent.change(screen.getByTestId("fee-coupon-input"), { target: { value: "DIWALI4" } });
    fireEvent.click(screen.getByTestId("fee-coupon-apply"));
    await screen.findByTestId("fee-coupon");
    await waitFor(() => expect(screen.getByTestId("escrow-review").textContent).toContain("₹10,400"));
    const payBtn = screen.getByTestId("escrow-pay");
    expect(payBtn.textContent).toMatch(/Pay ₹10,400\s*via UPI/); // v366 requirement change (see above)
    fireEvent.click(payBtn);
    // v366 requirement change (Ravi's checkout design): + a third arg with the Cancel flag / window-opened hook
    await waitFor(() => expect(onPay).toHaveBeenCalledWith("upi", "DIWALI4", expect.objectContaining({ cancel: { cancelled: false }, onOpen: expect.any(Function) })));
  });
});

describe("v365 UI · invoice", () => {
  const tx = { id: "t1", gross_amount: 10000, platform_fee_amount: 0, creator_net_amount: 10000, brand_fee_pct: 4, brand_fee_amount: 400, brand_fee_gst: 0, brand_paid_amount: 10400, coupon_code: "DIWALI4", created_at: "2026-10-20T10:00:00Z" };
  it("brand receipt: convenience-fee line with coupon, total billed = what the brand paid", () => {
    render(<InvoiceModal transaction={tx} isBrand onClose={() => {}} />);
    expect(screen.getByTestId("invoice-brand-fee").textContent).toMatch(/Convenience fee \(4%\).*Coupon DIWALI4 applied.*₹400/);
    expect(txt()).toMatch(/Total Billed Amount:\s*₹10,400\.00/);
    expect(txt()).toMatch(/Deal amount:\s*₹10,000\.00/);
  });
  it("creator receipt: 0% fee shows ₹0.00 (no '-₹0.00'), net = ₹10,000, no brand fee line", () => {
    render(<InvoiceModal transaction={tx} isBrand={false} creatorName="Riya" onClose={() => {}} />);
    expect(screen.queryByTestId("invoice-brand-fee")).toBeNull();
    expect(screen.getByTestId("invoice-creator-fee").textContent).toBe("₹0.00");
    expect(txt()).toMatch(/Net payout to creator:\s*₹10,000\.00/);
  });
  it("creator with an old 10% fee still sees the deduction", () => {
    render(<InvoiceModal transaction={{ ...tx, platform_fee_amount: 1000, creator_net_amount: 9000 }} isBrand={false} onClose={() => {}} />);
    expect(screen.getByTestId("invoice-creator-fee").textContent).toBe("-₹1,000.00");
  });
  it("old brand payment (no split columns): no fee line, total = deal", () => {
    render(<InvoiceModal transaction={{ id: "t0", gross_amount: 5000, platform_fee_amount: 500, creator_net_amount: 4500 }} isBrand onClose={() => {}} />);
    expect(screen.queryByTestId("invoice-brand-fee")).toBeNull();
    expect(txt()).toMatch(/Total Billed Amount:\s*₹5,000\.00/);
  });
});

describe("v365 UI · admin refund desk", () => {
  const tx = { id: "t1", brand_id: "b1", status: "ESCROW_HELD", gross_amount: 10000, platform_fee_amount: 0, creator_net_amount: 10000, brand_fee_pct: 8, brand_fee_amount: 800, brand_fee_gst: 0, brand_paid_amount: 10800, coupon_code: null };
  it("shows what the brand paid / service fee / coupon and the three quick fills", () => {
    render(<RefundModal transaction={tx} onClose={() => {}} />);
    const grid = screen.getByTestId("refund-brand-paid").textContent;
    expect(grid).toMatch(/Brand paid.*₹10,800/);
    expect(grid).toMatch(/Service fee 8%.*₹800/);
    const qf = screen.getByTestId("refund-quick-fill").textContent;
    expect(qf).toContain("Everything the brand paid · ₹10,800");
    expect(qf).toContain("Deal amount only · ₹10,000");
    expect(qf).toContain("Service fee only · ₹800");
  });
  it("'Service fee only' switches the source to the fee and the POST says refund_from: fee", async () => {
    apiMock.post.mockResolvedValue({ data: { success: true, transaction: {} } });
    const { container } = render(<RefundModal transaction={tx} onClose={() => {}} />);
    fireEvent.click(screen.getByText(/Service fee only/));
    const from = screen.getByTestId("refund-from").querySelectorAll("button");
    expect(from[1].className).toContain("border-[#9D7CFF]");
    expect(container.querySelector("input[type=number]").value).toBe("800");
    const utr = screen.getByPlaceholderText(/UPI\/602910481234/);
    fireEvent.change(utr, { target: { value: "UTR998877" } });
    fireEvent.submit(container.querySelector("form"));
    fireEvent.click(await screen.findByText(/Confirm & mark as paid/));
    await waitFor(() => expect(apiMock.post).toHaveBeenCalledWith("admin/transactions/t1/refund", expect.objectContaining({ refund_amount: 800, refund_from: "fee", refund_reference: "UTR998877" })));
  });
  it("no fee toggle and no brand-paid grid on an old payment", () => {
    render(<RefundModal transaction={{ id: "t0", status: "SUCCESS", gross_amount: 5000, platform_fee_amount: 500, creator_net_amount: 4500 }} onClose={() => {}} />);
    expect(screen.queryByTestId("refund-from")).toBeNull();
    expect(screen.queryByTestId("refund-brand-paid")).toBeNull();
  });
});

describe("v365 UI · admin fee boxes and coupon list", () => {
  it("split box: the example line is ₹10,000 → brand ₹10,800 · creator ₹10,000 · Ybex ₹800, and typing updates the config", () => {
    const setFeeConfig = vi.fn();
    const feeConfig = { fee_model: "split", creator_fee_pct: 0, brand_fee_pct: 8, threshold_amount: 50000, below_threshold_rate: 10, above_threshold_rate: 5, gst_rate: 18, platform_gst_registered: false, ugc_commission_rate: 10 };
    render(<FeesSettingsCard feeConfig={feeConfig} setFeeConfig={setFeeConfig} setShowFeeModal={() => {}} formatAmount={(n) => Number(n).toLocaleString("en-IN")} />);
    expect(screen.getByTestId("split-fee-example").textContent).toMatch(/Deal ₹10,000 → brand pays ₹10,800 · creator gets ₹10,000 · Ybex ₹800/);
    fireEvent.change(screen.getByTestId("brand-fee-pct"), { target: { value: "6" } });
    expect(setFeeConfig).toHaveBeenCalledWith(expect.objectContaining({ brand_fee_pct: 6 }));
  });
  it("an out-of-range brand fee is clamped in the example (30% max)", () => {
    const feeConfig = { fee_model: "split", creator_fee_pct: 0, brand_fee_pct: 80, threshold_amount: 50000 };
    render(<FeesSettingsCard feeConfig={feeConfig} setFeeConfig={() => {}} setShowFeeModal={() => {}} formatAmount={(n) => String(n)} />);
    expect(screen.getByTestId("split-fee-example").textContent).toContain("brand pays ₹13,000");
  });
  it("brand-fee coupons read 'Brand fee → 4%' / 'Brand fee 0%' / '₹300 off brand fee' for all brands", () => {
    const coupons = [
      { id: "1", code: "DIWALI4", type: "fee_rate_override", override_fee_rate: 4, applies_to: "brand_fee", is_active: true, used_count: 0 },
      { id: "2", code: "FREE", type: "zero_fee", applies_to: "brand_fee", is_active: true, used_count: 0 },
      { id: "3", code: "FLAT300", type: "flat_discount", discount_amount: 300, applies_to: "brand_fee", is_active: true, used_count: 0 },
    ];
    render(<CouponList coupons={coupons} loadingCoupons={false} handleEditCoupon={() => {}} handleToggleCouponStatus={() => {}} handleViewRedemptions={() => {}} setDeleteConfirmCoupon={() => {}} />);
    const t = txt();
    expect(t).toContain("Brand fee → 4%");
    expect(t).toContain("Brand fee 0%");
    expect(t).toContain("₹300 off brand fee");
    expect(t).toContain("Brand fee · all brands");
  });
});
