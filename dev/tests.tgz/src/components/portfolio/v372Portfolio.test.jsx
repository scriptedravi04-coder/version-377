// v372 (Ravi's screen recording 22 Oct): tag sheet close kept the tagged reels, "post" vs "reel", no close mid-save,
// honest Instagram error text.
import React from "react";
import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, fireEvent, cleanup, waitFor } from "@testing-library/react";

vi.mock("../../lib/challengeApi", () => ({ getMyChallenge: vi.fn(async () => null), stampEntries: vi.fn(async () => ({})) }));
const slow = vi.hoisted(() => ({ release: null }));
vi.mock("./portfolioApi", () => ({
  previewLink: vi.fn(async () => null),
  copyCovers: vi.fn(() => new Promise((ok) => { slow.release = () => ok({}); })),
  uploadFile: vi.fn(), videoCoverBlob: vi.fn(), fetchIgMedia: vi.fn(async () => []),
}));
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn() }) }));

import AddCollabsScreen from "./AddCollabsScreen";
import TagBrandSheet from "./TagBrandSheet";
import { igErrorText } from "../instagram/igFormat";

afterEach(() => { cleanup(); slow.release = null; });

const media = [
  { id: "1", permalink: "https://www.instagram.com/p/AAA111/", thumb: "https://img/1.jpg", likes: 408 },
  { id: "2", permalink: "https://www.instagram.com/reel/BBB222/", thumb: "https://img/2.jpg", views: 165 },
];
const Picker = ({ media: m, onChange }) => (
  <button type="button" onClick={() => onChange(m.map((x) => x.id))}>pick all</button>
);

describe("v372 · tag sheet", () => {
  it("a /p/ link is called a post, not a reel", () => {
    render(<TagBrandSheet group={{ key: "k", suggested: "", items: [{ id: "a", content_url: "https://www.instagram.com/p/AAA111/", likes: 408 }] }} onTag={() => {}} onNotCollab={() => {}} onClose={() => {}} />);
    expect(screen.getByText("1 post selected")).toBeTruthy(); // design 3b: compact reel row
    expect(screen.getByText(/408 likes/)).toBeTruthy();
    expect(screen.getByText(/is this post for\?/)).toBeTruthy();
  });

  it("closing the sheet half-way saves what was already tagged (it used to throw it away)", async () => {
    const onSave = vi.fn(async () => true);
    render(<AddCollabsScreen handle="me" media={media} existing={[]} onClose={() => {}} onSave={onSave} renderPicker={(p) => <Picker {...p} />} />);
    fireEvent.click(screen.getByText("pick all"));
    fireEvent.click(screen.getByText(/Next · tag brands/));
    fireEvent.change(screen.getByLabelText("Brand name"), { target: { value: "Trek" } });
    fireEvent.click(screen.getByText(/Tag 1 post as Trek/));
    // second sheet → X
    fireEvent.click(screen.getAllByLabelText("Close").at(-1));
    await waitFor(() => expect(slow.release).toBeTruthy());
    slow.release();
    await waitFor(() => expect(onSave).toHaveBeenCalled());
    const [items] = onSave.mock.calls[0];
    expect(items).toHaveLength(1);
    expect(items[0]).toMatchObject({ brand_name: "Trek", content_url: "https://www.instagram.com/p/AAA111/" });
  });

  it("the screen can't be closed while it is saving", async () => {
    const onClose = vi.fn();
    render(<AddCollabsScreen handle="me" media={media.slice(0, 1)} existing={[]} onClose={onClose} onSave={async () => true} renderPicker={(p) => <Picker {...p} />} />);
    fireEvent.click(screen.getByText("pick all"));
    fireEvent.click(screen.getByText(/Next · tag brand/));
    fireEvent.change(screen.getByLabelText("Brand name"), { target: { value: "Trek" } });
    fireEvent.click(screen.getByText(/Tag 1 post as Trek/));
    await waitFor(() => expect(slow.release).toBeTruthy());
    fireEvent.click(screen.getAllByLabelText("Close")[0]);
    expect(onClose).not.toHaveBeenCalled();
    slow.release();
    await waitFor(() => expect(onClose).toHaveBeenCalled());
  });
});

describe("v372 · Instagram error text", () => {
  it("no answer from the server is not 'account not found'", () => {
    expect(igErrorText(new Error("Network Error"), "x", "Couldn't find that account.")).toMatch(/Couldn't reach Ybex/);
    expect(igErrorText({ response: { status: 404, data: {} } }, "x", "Couldn't find that account.")).toBe("Couldn't find that account.");
    expect(igErrorText({ response: { status: 502, data: { error: "Instagram is busy right now." } } }, "x")).toBe("Instagram is busy right now.");
    expect(igErrorText({ response: { status: 500, data: {} } }, "Couldn't refresh. Try again.")).toBe("Couldn't refresh. Try again.");
  });
});

import { bentoLayout } from "./PortfolioViews";
describe("v372 · bento wall (design 4a)", () => {
  it("pins the Diwali entry big, then a mixed-size collage", () => {
    const it = (id, extra = {}) => ({ id, content_url: `https://www.instagram.com/reel/${id}AAAAA/`, date: "2026-01-01", ...extra });
    const t = bentoLayout([it("a", { views: 9000 }), it("b", { views: 100, challenge: "diwali2026", challenge_at: "x", challenge_sig: "s" }), it("c"), it("d"), it("e")]);
    expect(t[0]).toMatchObject({ pinned: true, size: "big" });
    expect(t[0].item.id).toBe("b");
    expect(new Set(t.slice(1).map((x) => x.size)).size).toBeGreaterThan(1); // not all the same size
    expect(bentoLayout([])).toEqual([]);
  });
});
